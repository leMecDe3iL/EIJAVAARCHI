package projet.commun.dto;

import java.io.Serializable;
import java.security.Timestamp;

@SuppressWarnings("serial")
public class DtoCours implements Serializable {

    // Champs

    private long id;
    private String horaire;
    private String niveauEtudes;
    private long salleId;
    private int capacite;
    private double montant;

    // Constructeurs

    public DtoCours() {
    }

    public DtoCours(long id, String horaire, String niveauEtudes, long salleId, int capacite, double montant) {
        this.id = id;
        this.horaire = horaire;
        this.niveauEtudes = niveauEtudes;
        this.salleId = salleId;
        this.capacite = capacite;
        this.montant = montant;
    }

    // Getters & Setters

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getHoraire() {
        return horaire;
    }

    public void setHoraire(String horaire) {
        this.horaire = horaire;
    }

    public String getNiveauEtudes() {
        return niveauEtudes;
    }

    public void setNiveauEtudes(String niveauEtudes) {
        this.niveauEtudes = niveauEtudes;
    }

    public long getSalleId() {
        return salleId;
    }

    public void setSalleId(long salleId) {
        this.salleId = salleId;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public double getMontant() {
        return montant;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }
}
