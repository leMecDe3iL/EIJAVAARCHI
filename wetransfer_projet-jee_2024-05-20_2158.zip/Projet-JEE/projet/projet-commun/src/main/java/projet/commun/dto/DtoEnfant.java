package projet.commun.dto;

import java.io.Serializable;
import java.util.Date;


@SuppressWarnings("serial")
public class DtoEnfant implements Serializable {

    // Champs

    private long id;
    private String nom;
    private String prenom;
    private Date dateNaissance;
    private String niveauEtudes;
    private String etablissementFrequente;
    
    private DtoCours coursChoisi;

    // Constructeurs

    public DtoEnfant() {
    }

    public DtoEnfant(long id, String nom, String prenom, Date dateNaissance, String niveauEtudes,
                     String etablissementFrequente, DtoCours coursChoisi) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.dateNaissance = dateNaissance;
        this.niveauEtudes = niveauEtudes;
        this.etablissementFrequente = etablissementFrequente;
        this.coursChoisi = coursChoisi;
    }

    // Getters & Setters

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Date getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

    public String getNiveauEtudes() {
        return niveauEtudes;
    }

    public void setNiveauEtudes(String niveauEtudes) {
        this.niveauEtudes = niveauEtudes;
    }

    public String getEtablissementFrequente() {
        return etablissementFrequente;
    }

    public void setEtablissementFrequente(String etablissementFrequente) {
        this.etablissementFrequente = etablissementFrequente;
    }

    public DtoCours getCoursChoisi() {
        return coursChoisi;
    }

    public void setCoursChoisi(DtoCours coursChoisi) {
        this.coursChoisi = coursChoisi;
    }
}
