package projet.commun.service;

import java.util.List;

import projet.commun.dto.DtoCours;
import projet.commun.exception.ExceptionValidation;

public interface IServiceCours {

    void creerCours(DtoCours dtoCours) throws ExceptionValidation;

    void modifierCours(DtoCours dtoCours) throws ExceptionValidation;

    void supprimerCours(long idCours) throws ExceptionValidation;

    DtoCours retrouverCours(long idCours);

    List<DtoCours> listerTousCours();

}
