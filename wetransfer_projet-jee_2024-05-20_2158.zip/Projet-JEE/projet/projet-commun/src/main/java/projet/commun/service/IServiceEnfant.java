package projet.commun.service;

import java.util.List;

import projet.commun.dto.DtoEnfant;
import projet.commun.exception.ExceptionValidation;

public interface IServiceEnfant {

    void creerEnfant(DtoEnfant dtoEnfant) throws ExceptionValidation;

    void modifierEnfant(DtoEnfant dtoEnfant) throws ExceptionValidation;

    void supprimerEnfant(long idEnfant) throws ExceptionValidation;

    DtoEnfant retrouverEnfant(long idEnfant);

    List<DtoEnfant> listerTousEnfants();

}
