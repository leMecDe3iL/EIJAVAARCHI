package enums;

public enum NiveauEtudes {
    SIXIEME,
    CINQUIEME,
    QUATRIEME,
    TROISIEME,
    SECONDE,
    PREMIERE,
    TERMINALE
}