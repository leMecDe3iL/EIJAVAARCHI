package enums;

public enum ModePaiement {
    CHEQUE,
    ESPECES,
    VIREMENT
}