SET search_path TO projet;


-- Supprime toutes les données
DELETE FROM Salle;
DELETE FROM Cours;
DELETE FROM Parent;
DELETE FROM Enfant;


-- Insère les données

-- Compte

INSERT INTO compte (idcompte, pseudo, motdepasse, email, flagadmin ) VALUES 
( 1, 'geek', 'geek', 'geek@jfox.fr', TRUE ),
( 2, 'chef', 'chef', 'chef@jfox.fr', FALSE ),
( 3, 'job', 'job', 'job@jfox.fr', FALSE );

ALTER TABLE compte ALTER COLUMN idcompte RESTART WITH 4;

-- Insertion des données dans la table Salle
INSERT INTO Salle (id, nom, capacite) VALUES
(1, 'Salle A', 30),
(2,'Salle B', 25),
(3, 'Salle C', 35);

ALTER TABLE Salle ALTER COLUMN id RESTART WITH 10;

-- Insertion des données dans la table Cours
INSERT INTO Cours (horaire, niveau_etudes, salle_id, capacite, montant) VALUES
('2024-05-05 10:00:00', 'SIXIEME', 1, 20, 50.00),
('2024-05-05 14:00:00', 'SIXIEME', 2, 15, 50.00),
('2024-05-06 10:00:00', 'CINQUIEME', 1, 25, 50.00),
('2024-05-06 14:00:00', 'CINQUIEME', 3, 30, 50.00);

-- Insertion des données dans la table Parent
INSERT INTO Parent (nom, prenom, email, mot_de_passe, mode_paiement, nombre_paiements, solde_restant) VALUES
('Dupont', 'Jean', 'jean.dupont@example.com', 'mdp123', 'Chèque', 0, 0.00),
('Durand', 'Marie', 'marie.durand@example.com', 'mdp456', 'Espèces', 0, 0.00);

-- Insertion des données dans la table Enfant
INSERT INTO Enfant (nom, prenom, date_de_naissance, niveau_etudes, etablissement_frequente, parent_id) VALUES
('Dupont', 'Lucie', '2010-03-15', 'Sixième', 'Collège Sainte-Marie', 1),
('Durand', 'Pierre', '2008-07-20', 'Cinquième', 'Collège Jean Moulin', 2);

