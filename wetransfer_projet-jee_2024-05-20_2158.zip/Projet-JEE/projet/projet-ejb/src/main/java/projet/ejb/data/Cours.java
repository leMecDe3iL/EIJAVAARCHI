package projet.ejb.data;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table( name = "cours" )
public class Cours {
	  // Champs
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "horaire", nullable = false)
    private String horaire;

    @Column(name = "niveau_etudes", nullable = false)
    private String niveauEtudes;

    @Column(name = "capacite", nullable = false)
    private int capacite;

    @Column(name = "montant", nullable = false)
    private double montant;

    @ManyToOne
    @JoinColumn(name = "salle_id")
    private Salle salle;

    // Constructeurs
    public Cours() {
    }

    public Cours(String horaire, String niveauEtudes, int capacite, double montant, Salle salle) {
        this.horaire = horaire;
        this.niveauEtudes = niveauEtudes;
        this.capacite = capacite;
        this.montant = montant;
        this.salle = salle;
    }

	public String getHoraire() {
		return horaire;
	}

	public void setHoraire(String horaire) {
		this.horaire = horaire;
	}

	public String getNiveauEtudes() {
		return niveauEtudes;
	}

	public void setNiveauEtudes(String niveauEtudes) {
		this.niveauEtudes = niveauEtudes;
	}

	public int getCapacite() {
		return capacite;
	}

	public void setCapacite(int capacite) {
		this.capacite = capacite;
	}

	public double getMontant() {
		return montant;
	}

	public void setMontant(double montant) {
		this.montant = montant;
	}

	public Salle getSalle() {
		return salle;
	}

	public void setSalle(Salle salle) {
		this.salle = salle;
	}

	@Override
	public int hashCode() {
		return Objects.hash(capacite, horaire, id, montant, niveauEtudes, salle);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cours other = (Cours) obj;
		return capacite == other.capacite && Objects.equals(horaire, other.horaire) && Objects.equals(id, other.id)
				&& Double.doubleToLongBits(montant) == Double.doubleToLongBits(other.montant)
				&& Objects.equals(niveauEtudes, other.niveauEtudes) && Objects.equals(salle, other.salle);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

    
}
