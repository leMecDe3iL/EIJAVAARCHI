package projet.ejb.data;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "enfants")
public class Enfant {
    // Champs
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "nom", nullable = false)
    private String nom;

    @Column(name = "prenom", nullable = false)
    private String prenom;

    @Column(name = "date_naissance", nullable = false)
    private Date dateNaissance;

    @Column(name = "niveau_etudes", nullable = false)
    private String niveauEtudes;

    @Column(name = "etablissement_frequente", nullable = false)
    private String etablissementFrequente;

    @ManyToOne
    @JoinColumn(name = "cours_id")
    private Cours cours;

    // Constructeurs
    public Enfant() {
    }

    public Enfant(String nom, String prenom, Date dateNaissance, String niveauEtudes, String etablissementFrequente, Cours cours) {
        this.nom = nom;
        this.prenom = prenom;
        this.dateNaissance = dateNaissance;
        this.niveauEtudes = niveauEtudes;
        this.etablissementFrequente = etablissementFrequente;
        this.cours = cours;
    }

    // Getters et setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Date getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

    public String getNiveauEtudes() {
        return niveauEtudes;
    }

    public void setNiveauEtudes(String niveauEtudes) {
        this.niveauEtudes = niveauEtudes;
    }

    public String getEtablissementFrequente() {
        return etablissementFrequente;
    }

    public void setEtablissementFrequente(String etablissementFrequente) {
        this.etablissementFrequente = etablissementFrequente;
    }

    public Cours getCours() {
        return cours;
    }

    public void setCours(Cours cours) {
        this.cours = cours;
    }

	@Override
	public int hashCode() {
		return Objects.hash(cours, dateNaissance, etablissementFrequente, id, niveauEtudes, nom, prenom);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Enfant other = (Enfant) obj;
		return Objects.equals(cours, other.cours) && Objects.equals(dateNaissance, other.dateNaissance)
				&& Objects.equals(etablissementFrequente, other.etablissementFrequente) && Objects.equals(id, other.id)
				&& Objects.equals(niveauEtudes, other.niveauEtudes) && Objects.equals(nom, other.nom)
				&& Objects.equals(prenom, other.prenom);
	}

	@Override
	public String toString() {
		return "Enfant [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", dateNaissance=" + dateNaissance
				+ ", niveauEtudes=" + niveauEtudes + ", etablissementFrequente=" + etablissementFrequente + ", cours="
				+ cours + "]";
	}

    
}

