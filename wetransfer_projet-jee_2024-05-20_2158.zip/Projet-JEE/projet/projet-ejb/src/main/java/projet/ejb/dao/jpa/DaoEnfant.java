package projet.ejb.dao.jpa;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import projet.ejb.dao.IDaoEnfant;
import projet.ejb.data.Enfant;

import static javax.ejb.TransactionAttributeType.MANDATORY;
import static javax.ejb.TransactionAttributeType.NOT_SUPPORTED;

import java.util.List;

@Stateless
@Local
@TransactionAttribute(MANDATORY)
public class DaoEnfant implements IDaoEnfant {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void creerEnfant(Enfant enfant) {
        entityManager.persist(enfant);
    }

    @Override
    public void modifierEnfant(Enfant enfant) {
        entityManager.merge(enfant);
    }

    @Override
    public void supprimerEnfant(long idEnfant) {
        Enfant enfant = retrouverEnfant(idEnfant);
        if (enfant != null) {
            entityManager.remove(enfant);
        }
    }

    @Override
    @TransactionAttribute(NOT_SUPPORTED)
    public Enfant retrouverEnfant(long idEnfant) {
        return entityManager.find(Enfant.class, idEnfant);
    }

    @Override
    @TransactionAttribute(NOT_SUPPORTED)
    public List<Enfant> listerTousEnfants() {
        Query query = entityManager.createQuery("SELECT e FROM Enfant e");
        return query.getResultList();
    }

    // Ajoutez d'autres méthodes pour la manipulation des enfants si nécessaire
}
