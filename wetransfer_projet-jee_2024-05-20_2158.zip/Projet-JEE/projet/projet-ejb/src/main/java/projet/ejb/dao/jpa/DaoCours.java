package projet.ejb.dao.jpa;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import projet.ejb.dao.IDaoCours;
import projet.ejb.data.Cours;

import static javax.ejb.TransactionAttributeType.MANDATORY;
import static javax.ejb.TransactionAttributeType.NOT_SUPPORTED;

import java.util.List;




@Stateless
@Local
@TransactionAttribute( MANDATORY )
public class DaoCours implements IDaoCours {

	@PersistenceContext
    private EntityManager entityManager;

    @Override
    public void creerCours(Cours cours) {
        entityManager.persist(cours);
    }

    @Override
    public void modifierCours(Cours cours) {
        entityManager.merge(cours);
    }

    @Override
    public void supprimerCours(long idCours) {
        Cours cours = retrouverCours(idCours);
        if (cours != null) {
            entityManager.remove(cours);
        }
    }

    @Override
    @TransactionAttribute( NOT_SUPPORTED )
    public Cours retrouverCours(long idCours) {
        return entityManager.find(Cours.class, idCours);
    }

    @Override
	@TransactionAttribute( NOT_SUPPORTED )
    public List<Cours> listerTousCours() {
        Query query = entityManager.createQuery("SELECT c FROM Cours c");
        return query.getResultList();
    }

    // Ajoutez d'autres méthodes pour la manipulation des cours si nécessaire
}

