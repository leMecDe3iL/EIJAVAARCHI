package projet.ejb.dao.jpa;

import java.util.List;

import projet.jsf.data.Parent;

public interface ParentDAO {
    void save(Parent parent); // Enregistre un parent dans la base de données
    Parent findById(Long id); // Récupère un parent par son identifiant
    Parent findByEmail(String email); // Récupère un parent par son adresse e-mail
    List<Parent> findAll(); // Récupère tous les parents de la base de données
    void update(Parent parent); // Met à jour les informations d'un parent dans la base de données
    void delete(Long id); // Supprime un parent de la base de données par son identifiant
}