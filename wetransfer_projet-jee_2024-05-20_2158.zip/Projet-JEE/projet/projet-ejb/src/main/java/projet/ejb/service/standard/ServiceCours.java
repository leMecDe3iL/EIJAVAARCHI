package projet.ejb.service.standard;

import static javax.ejb.TransactionAttributeType.NOT_SUPPORTED;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.inject.Inject;

import projet.commun.dto.DtoCours;
import projet.commun.exception.ExceptionValidation;
import projet.commun.service.IServiceCours;
import projet.ejb.dao.IDaoCours;
import projet.ejb.data.Cours;
import projet.ejb.data.mapper.IMapperEjb;

@Stateless
@Remote
public class ServiceCours implements IServiceCours {

    // Champs
    @Inject
    private IMapperEjb mapper;
    @Inject
    private IDaoCours daoCours;

    // Actions

    @Override
    public void creerCours(DtoCours dtoCours) throws ExceptionValidation {
        verifierValiditeDonnees(dtoCours);
        daoCours.creerCours(mapper.map(dtoCours));
    }

    @Override
    public void modifierCours(DtoCours dtoCours) throws ExceptionValidation {
        verifierValiditeDonnees(dtoCours);
        daoCours.modifierCours(mapper.map(dtoCours));
    }

    @Override
    public void supprimerCours(long idCours) throws ExceptionValidation {
        daoCours.supprimerCours(idCours);
    }

    @Override
    @TransactionAttribute(NOT_SUPPORTED)
    public DtoCours retrouverCours(long idCours) {
        return mapper.map(daoCours.retrouverCours(idCours));
    }

    @Override
    @TransactionAttribute(NOT_SUPPORTED)
    public List<DtoCours> listerTousCours() {
        List<DtoCours> liste = new ArrayList<>();
        System.out.println("DAOCours " + daoCours.listerTousCours().size());
        for (Cours cours : daoCours.listerTousCours()) {
            liste.add(mapper.map(cours));
        }
        return liste;
    }

    // Méthodes auxiliaires

    private void verifierValiditeDonnees(DtoCours dtoCours) throws ExceptionValidation {
        // Ajoutez vos vérifications de validation ici selon les besoins de votre application
    }
}
