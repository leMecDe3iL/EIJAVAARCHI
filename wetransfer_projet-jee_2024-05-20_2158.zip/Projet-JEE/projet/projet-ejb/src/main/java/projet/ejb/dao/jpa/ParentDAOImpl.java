package projet.ejb.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import projet.jsf.data.Parent;

@Repository
@Transactional
public class ParentDAOImpl implements ParentDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void save(Parent parent) {
        entityManager.persist(parent);
    }

    @Override
    public Parent findById(Long id) {
        return entityManager.find(Parent.class, id);
    }

    @Override
    public Parent findByEmail(String email) {
        // Implémentez la logique pour rechercher un parent par email
        // Cette logique peut impliquer une requête à votre base de données pour récupérer le parent avec l'email spécifié
        // Par exemple, vous pouvez utiliser JPA pour effectuer la requête
        return entityManager.createQuery("SELECT p FROM Parent p WHERE p.email = :email", Parent.class)
                .setParameter("email", email)
                .getSingleResult();
    }
    
    @Override
    public List<Parent> findAll() {
        return entityManager.createQuery("SELECT p FROM Parent p", Parent.class)
                .getResultList();
    }

    @Override
    public void update(Parent parent) {
        entityManager.merge(parent);
    }

    @Override
    public void delete(Long id) {
        Parent parent = entityManager.find(Parent.class, id);
        if (parent != null) {
            entityManager.remove(parent);
        }
    }

    // Ajoutez d'autres méthodes pour la manipulation des parents si nécessaire
}
