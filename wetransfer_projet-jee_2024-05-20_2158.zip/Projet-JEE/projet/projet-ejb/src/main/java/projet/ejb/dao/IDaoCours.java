package projet.ejb.dao;

import java.util.List;

import projet.ejb.data.Cours;


public interface IDaoCours {
	 void creerCours(Cours cours);

	    void modifierCours(Cours cours);

	    void supprimerCours(long idCours);

	    Cours retrouverCours(long idCours);

	    List<Cours> listerTousCours();
}
