package projet.ejb.dao;

import java.util.List;

import projet.ejb.data.Enfant;

public interface IDaoEnfant {
    void creerEnfant(Enfant enfant);

    void modifierEnfant(Enfant enfant);

    void supprimerEnfant(long idEnfant);

    Enfant retrouverEnfant(long idEnfant);

    List<Enfant> listerTousEnfants();
}
