package projet.ejb.service.standard;

import static javax.ejb.TransactionAttributeType.NOT_SUPPORTED;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.inject.Inject;

import projet.commun.dto.DtoEnfant;
import projet.commun.exception.ExceptionValidation;
import projet.commun.service.IServiceEnfant;
import projet.ejb.dao.IDaoEnfant;
import projet.ejb.data.Enfant;
import projet.ejb.data.mapper.IMapperEjb;

@Stateless
@Remote
public class ServiceEnfant implements IServiceEnfant {

    // Champs
    @Inject
    private IMapperEjb mapper;
    @Inject
    private IDaoEnfant daoEnfant;

    // Actions

    @Override
    public void creerEnfant(DtoEnfant dtoEnfant) throws ExceptionValidation {
        verifierValiditeDonnees(dtoEnfant);
        daoEnfant.creerEnfant(mapper.map(dtoEnfant));
    }

    @Override
    public void modifierEnfant(DtoEnfant dtoEnfant) throws ExceptionValidation {
        verifierValiditeDonnees(dtoEnfant);
        daoEnfant.modifierEnfant(mapper.map(dtoEnfant));
    }

    @Override
    public void supprimerEnfant(long idEnfant) throws ExceptionValidation {
        daoEnfant.supprimerEnfant(idEnfant);
    }

    @Override
    @TransactionAttribute(NOT_SUPPORTED)
    public DtoEnfant retrouverEnfant(long idEnfant) {
        return mapper.map(daoEnfant.retrouverEnfant(idEnfant));
    }

    @Override
    @TransactionAttribute(NOT_SUPPORTED)
    public List<DtoEnfant> listerTousEnfants() {
        List<DtoEnfant> liste = new ArrayList<>();
        System.out.println("DAOEnfant " + daoEnfant.listerTousEnfants().size());
        for (Enfant enfant : daoEnfant.listerTousEnfants()) {
            liste.add(mapper.map(enfant));
        }
        return liste;
    }

    // Méthodes auxiliaires

    private void verifierValiditeDonnees(DtoEnfant dtoEnfant) throws ExceptionValidation {
    	  if (dtoEnfant.getNom() == null || dtoEnfant.getNom().isEmpty()) {
    	        throw new ExceptionValidation("Le nom de l'enfant est obligatoire.");
    	    }
    	    if (dtoEnfant.getPrenom() == null || dtoEnfant.getPrenom().isEmpty()) {
    	        throw new ExceptionValidation("Le prénom de l'enfant est obligatoire.");
    	    }
    	    if (dtoEnfant.getDateNaissance() == null) {
    	        throw new ExceptionValidation("La date de naissance de l'enfant est obligatoire.");
    	    }
    	    if (dtoEnfant.getNiveauEtudes() == null || dtoEnfant.getNiveauEtudes().isEmpty()) {
    	        throw new ExceptionValidation("Le niveau d'études de l'enfant est obligatoire.");
    	    }
    	    if (dtoEnfant.getEtablissementFrequente() == null || dtoEnfant.getEtablissementFrequente().isEmpty()) {
    	        throw new ExceptionValidation("L'établissement fréquenté par l'enfant est obligatoire.");
    	    }
    	    if (dtoEnfant.getCoursChoisi() == null || dtoEnfant.getCoursChoisi().isEmpty()) {
    	        throw new ExceptionValidation("Le cours choisi par l'enfant est obligatoire.");
    	    }
    }
}
