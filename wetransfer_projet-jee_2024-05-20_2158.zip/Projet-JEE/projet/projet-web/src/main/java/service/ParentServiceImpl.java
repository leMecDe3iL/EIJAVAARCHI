package service;

import java.util.ArrayList;
import java.util.List;


import dto.EnfantDTO;
import dto.ParentDTO;
import exception.CapaciteSalleDepasseeException;
import projet.jsf.data.Cours;
import projet.jsf.data.Enfant;
import projet.jsf.data.Parent;

public class ParentServiceImpl implements ParentService {
    private ParentDAO parentDAO;
    private EnfantDAO enfantDAO;
    private DaoCours coursDAO;

    // Constructeur

   
    
    @Override
    public void inscrireEnfant(Long parentId, EnfantDTO enfantDTO) throws CapaciteSalleDepasseeException {
        Parent parent = parentDAO.findById(parentId);
        if (parent == null) {
            throw new IllegalArgumentException("Parent not found");
        }

        Cours cours = coursDAO.findById(enfantDTO.getCoursChoisiId());
        if (cours == null) {
            throw new IllegalArgumentException("Course not found");
        }

        if (cours.getCapacite() <= cours.getEnfantsInscrits().size()) {
            throw new CapaciteSalleDepasseeException("Capacity of the room exceeded");
        }

        Enfant enfant = new Enfant();
        enfant.setNom(enfantDTO.getNom());
        enfant.setPrenom(enfantDTO.getPrenom());
        enfant.setDateDeNaissance(enfantDTO.getDateDeNaissance());
        enfant.setNiveauEtudes(enfantDTO.getNiveauEtudes());
        enfant.setEtablissementFrequente(enfantDTO.getEtablissementFrequente());
        enfant.setCoursChoisi(cours);
        enfantDAO.save(enfant);

        cours.getEnfantsInscrits().add(enfant);
        coursDAO.save(cours);
    }

    @Override
    public ParentDTO getParent(Long parentId) {
        Parent parent = parentDAO.findById(parentId);
        return convertToDTO(parent);
    }

    @Override
    public List<EnfantDTO> getEnfants(Long parentId) {
        Parent parent = parentDAO.findById(parentId);
        List<EnfantDTO> enfantsDTO = new ArrayList<>();
        for (Enfant enfant : parent.getEnfants()) {
            enfantsDTO.add(convertToDTO(enfant));
        }
        return enfantsDTO;
    }

    @Override
    public double getSoldeRestant(Long parentId) {
        Parent parent = parentDAO.findById(parentId);
        return parent.getSoldeRestant();
    }

    private ParentDTO convertToDTO(Parent parent) {
        ParentDTO parentDTO = new ParentDTO();
        parentDTO.setId(parent.getId());
        parentDTO.setNom(parent.getNom());
        parentDTO.setPrenom(parent.getPrenom());
        parentDTO.setEmail(parent.getEmail());
        parentDTO.setMotDePasse(parent.getMotDePasse());
        parentDTO.setModePaiement(parent.getModePaiement());
        parentDTO.setNombrePaiements(parent.getNombrePaiements());
        parentDTO.setSoldeRestant(parent.getSoldeRestant());
        return parentDTO;
    }

    private EnfantDTO convertToDTO(Enfant enfant) {
        EnfantDTO enfantDTO = new EnfantDTO();
        enfantDTO.setId(enfant.getId());
        enfantDTO.setNom(enfant.getNom());
        enfantDTO.setPrenom(enfant.getPrenom());
        enfantDTO.setDateDeNaissance(enfant.getDateDeNaissance());
        enfantDTO.setNiveauEtudes(enfant.getNiveauEtudes());
        enfantDTO.setEtablissementFrequente(enfant.getEtablissementFrequente());
        enfantDTO.setCoursChoisiId(enfant.getCoursChoisi().getId());
        return enfantDTO;
    }


}