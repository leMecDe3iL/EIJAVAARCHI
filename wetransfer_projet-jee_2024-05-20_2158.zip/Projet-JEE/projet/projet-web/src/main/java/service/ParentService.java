package service;

import java.util.List;

import dto.EnfantDTO;
import dto.ParentDTO;
import exception.CapaciteSalleDepasseeException;

public interface ParentService {
    void inscrireEnfant(Long parentId, EnfantDTO enfantDTO) throws CapaciteSalleDepasseeException;
    ParentDTO getParent(Long parentId);
    List<EnfantDTO> getEnfants(Long parentId);
    double getSoldeRestant(Long parentId);
}
