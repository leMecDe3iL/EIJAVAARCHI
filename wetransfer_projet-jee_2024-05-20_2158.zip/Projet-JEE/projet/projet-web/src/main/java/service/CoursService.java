package service;

import java.time.LocalDateTime;
import java.util.List;

import dto.CoursDTO;
import dto.EnfantDTO;
import enums.NiveauEtudes;

public interface CoursService {
    List<CoursDTO> getCoursDisponibles();
    List<CoursDTO> getCoursDisponiblesPourNiveau(NiveauEtudes niveauEtudes);
    List<CoursDTO> getCoursDisponiblesALHoraire(LocalDateTime horaire);
    List<EnfantDTO> getEnfantsInscrits(Long coursId);
}
