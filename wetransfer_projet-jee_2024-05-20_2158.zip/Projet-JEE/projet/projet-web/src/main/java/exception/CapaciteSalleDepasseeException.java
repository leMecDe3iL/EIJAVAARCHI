package exception;

public class CapaciteSalleDepasseeException extends Exception {
    public CapaciteSalleDepasseeException(String message) {
        super(message);
    }
}
