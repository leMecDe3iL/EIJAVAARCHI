package projet.jsf.data;

import java.util.List;

import enums.NiveauEtudes;


public class Cours {
    private Long id;
    private String horaire;
    private NiveauEtudes niveauEtudes;
    private Salle salle;
    private int capacite;
    private double montant;
    private List<Enfant> enfantsInscrits;

    // Getters et Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getHoraire() {
        return horaire;
    }
    public void setHoraire(String horaire) {
        this.horaire = horaire;
    }

    public NiveauEtudes getNiveauEtudes() {
        return niveauEtudes;
    }
    public void setNiveauEtudes(NiveauEtudes niveauEtudes) {
        this.niveauEtudes = niveauEtudes;
    }

    public Salle getSalle() {
        return salle;
    }
    public void setSalle(Salle salle) {
        this.salle = salle;
    }

    public int getCapacite() {
        return capacite;
    }
    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public double getMontant() {
        return montant;
    }
    public void setMontant(double montant) {
        this.montant = montant;
    }

    public List<Enfant> getEnfantsInscrits() {
        return enfantsInscrits;
    }
    public void setEnfantsInscrits(List<Enfant> enfantsInscrits) {
        this.enfantsInscrits = enfantsInscrits;
    }
}