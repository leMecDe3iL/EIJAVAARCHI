package projet.jsf.data;

import java.time.LocalDate;
import java.util.Date;

import enums.NiveauEtudes;

public class Enfant {
    private Long id;
    private String nom;
    private String prenom;
    private Date dateDeNaissance;
    private NiveauEtudes niveauEtudes;
    private String etablissementFrequente;
    private Cours coursChoisi;

    // Constructeurs
    public Enfant() {
    }

    public Enfant(String nom, String prenom, Date dateDeNaissance, NiveauEtudes niveauEtudes, String etablissementFrequente, Cours coursChoisi) {
        this.nom = nom;
        this.prenom = prenom;
        this.dateDeNaissance = dateDeNaissance;
        this.niveauEtudes = niveauEtudes;
        this.etablissementFrequente = etablissementFrequente;
        this.coursChoisi = coursChoisi;
    }

    // Getters et setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Date getDateDeNaissance() {
        return dateDeNaissance;
    }

    public void setDateDeNaissance(Date dateDeNaissance) {
        this.dateDeNaissance = dateDeNaissance;
    }

    public NiveauEtudes getNiveauEtudes() {
        return niveauEtudes;
    }

    public void setNiveauEtudes(NiveauEtudes niveauEtudes) {
        this.niveauEtudes = niveauEtudes;
    }

    public String getEtablissementFrequente() {
        return etablissementFrequente;
    }

    public void setEtablissementFrequente(String etablissementFrequente) {
        this.etablissementFrequente = etablissementFrequente;
    }

    public Cours getCoursChoisi() {
        return coursChoisi;
    }

    public void setCoursChoisi(Cours coursChoisi) {
        this.coursChoisi = coursChoisi;
    }
}
