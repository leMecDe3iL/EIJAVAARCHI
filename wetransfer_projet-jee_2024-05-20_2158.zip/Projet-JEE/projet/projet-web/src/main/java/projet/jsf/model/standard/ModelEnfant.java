package projet.jsf.model.standard;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import projet.commun.dto.DtoCours;
import projet.commun.dto.DtoEnfant;
import projet.commun.exception.ExceptionValidation;
import projet.commun.service.IServiceCours;
import projet.commun.service.IServiceEnfant;
import projet.jsf.data.Enfant;
import projet.jsf.data.mapper.IMapper;
import projet.jsf.util.UtilJsf;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class ModelEnfant implements Serializable {

	// Champs

	private List<Enfant> liste;

	private Enfant courant;

	@EJB
	private IServiceEnfant serviceEnfant;

	@EJB
	private IServiceCours serviceCours;

	private List<DtoCours> listeCours;

	@Inject
	private IMapper mapper;

	// Getters

	public List<Enfant> getListe() {
		try {
			if (liste == null) {
				liste = new ArrayList<>();
				for (DtoEnfant dto : serviceEnfant.listerTousEnfants()) {
					liste.add(mapper.map(dto));
				}
			}
			return liste;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Enfant getCourant() {
		if (courant == null) {
			courant = new Enfant();
		}
		return courant;
	}

	public List<DtoCours> getListeCours() {
		if (listeCours == null) {
			listeCours = serviceCours.listerTousCours();
		}
		return listeCours;
	}
	// Initialisations

	public String actualiserCourant() {
		if (courant != null) {
			DtoEnfant dto = serviceEnfant.retrouverEnfant(courant.getId());
			if (dto == null) {
				UtilJsf.messageError("L'enfant demandé n'existe pas");
				return "liste";
			} else {
				courant = mapper.map(dto);
			}
		}
		return null;
	}

	// Actions

	public String validerMiseAJour() {
	    // Récupérer l'identifiant du cours choisi par l'élève
		long idCoursChoisi = courant.getCoursChoisi().getId();
		
		// Vérifier si un cours a été choisi
		if (idCoursChoisi <= 0) {
		    UtilJsf.messageError("Veuillez sélectionner un cours.");
		    return null;
		}
		
		// Récupérer les détails du cours choisi à partir de son identifiant
		DtoCours coursChoisi = serviceCours.retrouverCours(idCoursChoisi);
		
		// Vérifier si le cours existe
		if (coursChoisi == null) {
		    UtilJsf.messageError("Le cours sélectionné n'existe pas.");
		    return null;
		}
	    return null;
	}

	public String supprimer(Enfant item) {
		try {
			serviceEnfant.supprimerEnfant(item.getId());
			liste.remove(item);
			UtilJsf.messageInfo("Suppression effectuée avec succès.");
		} catch (ExceptionValidation e) {
			UtilJsf.messageError(e);
		}
		return null;
	}
}
