package projet.jsf.data;

import java.util.ArrayList;
import java.util.List;

import enums.ModePaiement;

public class Parent {
    private Long id;
    private String nom;
    private String prenom;
    private String email;
    private String motDePasse;
    private ModePaiement modePaiement;
    private int nombrePaiements;
    private double soldeRestant;
    private List<Enfant> enfants; 

    // Getters et Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getMotDePasse() {
        return motDePasse;
    }
    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public ModePaiement getModePaiement() {
        return modePaiement;
    }
    public void setModePaiement(ModePaiement modePaiement) {
        this.modePaiement = modePaiement;
    }

    public int getNombrePaiements() {
        return nombrePaiements;
    }
    public void setNombrePaiements(int nombrePaiements) {
        this.nombrePaiements = nombrePaiements;
    }

    public double getSoldeRestant() {
        return soldeRestant;
    }
    public void setSoldeRestant(double soldeRestant) {
        this.soldeRestant = soldeRestant;
    }
    
    public List<Enfant> getEnfants() {
        if (enfants == null) {
            enfants = new ArrayList<>();
        }
        return enfants;
    }

    public void setEnfants(List<Enfant> enfants) {
        this.enfants = enfants;
    }
}

