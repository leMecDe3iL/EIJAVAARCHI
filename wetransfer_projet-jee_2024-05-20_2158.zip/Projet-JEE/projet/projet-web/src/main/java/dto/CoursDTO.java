package dto;

import java.util.Objects;

import enums.NiveauEtudes;

public class CoursDTO {
    private Long id;
    private String horaire;
    private NiveauEtudes niveauEtudes;
    private Long salleId;
    private int capacite;
    private double montant;

    // Constructeurs
    public CoursDTO(Long id, String horaire, NiveauEtudes niveauEtudes, Long salleId, int capacite, double montant) {
        this.id = id;
        this.horaire = horaire;
        this.niveauEtudes = niveauEtudes;
        this.salleId = salleId;
        this.capacite = capacite;
        this.montant = montant;
    }

    // Getters et Setters

    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getHoraire() {
        return horaire;
    }
    public void setHoraire(String horaire) {
        this.horaire = horaire;
    }

    public NiveauEtudes getNiveauEtudes() {
        return niveauEtudes;
    }
    public void setNiveauEtudes(NiveauEtudes niveauEtudes) {
        this.niveauEtudes = niveauEtudes;
    }

    public Long getSalleId() {
        return salleId;
    }
    public void setSalleId(Long salleId) {
        this.salleId = salleId;
    }

    public int getCapacite() {
        return capacite;
    }
    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public double getMontant() {
        return montant;
    }
    public void setMontant(double montant) {
        this.montant = montant;
    }
    
    
    
    // Equals et HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CoursDTO coursDTO = (CoursDTO) o;
        return capacite == coursDTO.capacite && Double.compare(coursDTO.montant, montant) == 0 && Objects.equals(id, coursDTO.id) && Objects.equals(horaire, coursDTO.horaire) && niveauEtudes == coursDTO.niveauEtudes && Objects.equals(salleId, coursDTO.salleId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, horaire, niveauEtudes, salleId, capacite, montant);
    }

    // ToString
    @Override
    public String toString() {
        return "CoursDTO{" +
                "id=" + id +
                ", horaire=" + horaire +
                ", niveauEtudes=" + niveauEtudes +
                ", salleId=" + salleId +
                ", capacite=" + capacite +
                ", montant=" + montant +
                '}';
    }
}