package dto;

import java.util.Objects;

import enums.ModePaiement;

public class ParentDTO {
    private Long id;
    private String nom;
    private String prenom;
    private String email;
    private String motDePasse;
    private ModePaiement modePaiement;
    private int nombrePaiements;
    private double soldeRestant;

    // Constructeurs
    public ParentDTO() {}

    public ParentDTO(Long id, String nom, String prenom, String email, String motDePasse, ModePaiement modePaiement, int nombrePaiements, double soldeRestant) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.motDePasse = motDePasse;
        this.modePaiement = modePaiement;
        this.nombrePaiements = nombrePaiements;
        this.soldeRestant = soldeRestant;
    }



    
    
 // Getters et Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getMotDePasse() {
        return motDePasse;
    }
    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public ModePaiement getModePaiement() {
        return modePaiement;
    }
    public void setModePaiement(ModePaiement modePaiement) {
        this.modePaiement = modePaiement;
    }

    public int getNombrePaiements() {
        return nombrePaiements;
    }
    public void setNombrePaiements(int nombrePaiements) {
        this.nombrePaiements = nombrePaiements;
    }

    public double getSoldeRestant() {
        return soldeRestant;
    }
    public void setSoldeRestant(double soldeRestant) {
        this.soldeRestant = soldeRestant;
    }
    
    
    
    
    
    
    // Equals et HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ParentDTO parentDTO = (ParentDTO) o;
        return nombrePaiements == parentDTO.nombrePaiements && Double.compare(parentDTO.soldeRestant, soldeRestant) == 0 && Objects.equals(id, parentDTO.id) && Objects.equals(nom, parentDTO.nom) && Objects.equals(prenom, parentDTO.prenom) && Objects.equals(email, parentDTO.email) && Objects.equals(motDePasse, parentDTO.motDePasse) && modePaiement == parentDTO.modePaiement;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nom, prenom, email, motDePasse, modePaiement, nombrePaiements, soldeRestant);
    }

    // ToString
    @Override
    public String toString() {
        return "ParentDTO{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", email='" + email + '\'' +
                ", motDePasse='" + motDePasse + '\'' +
                ", modePaiement=" + modePaiement +
                ", nombrePaiements=" + nombrePaiements +
                ", soldeRestant=" + soldeRestant +
                '}';
    }
}