package dto;

import java.time.LocalDate;
import java.util.Objects;

import enums.NiveauEtudes;

public class EnfantDTO {
    private Long id;
    private String nom;
    private String prenom;
    private LocalDate dateDeNaissance;
    private NiveauEtudes niveauEtudes;
    private String etablissementFrequente;
    private Long coursChoisiId;

    // Constructeurs
    public EnfantDTO() {}

    public EnfantDTO(Long id, String nom, String prenom, LocalDate dateDeNaissance, NiveauEtudes niveauEtudes, String etablissementFrequente, Long coursChoisiId) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.dateDeNaissance = dateDeNaissance;
        this.niveauEtudes = niveauEtudes;
        this.etablissementFrequente = etablissementFrequente;
        this.coursChoisiId = coursChoisiId;
    }

    // Getters et Setters
    // (Inclure les getters et setters pour chaque champ)

    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public LocalDate getDateDeNaissance() {
        return dateDeNaissance;
    }
    public void setDateDeNaissance(LocalDate dateDeNaissance) {
        this.dateDeNaissance = dateDeNaissance;
    }

    public NiveauEtudes getNiveauEtudes() {
        return niveauEtudes;
    }
    public void setNiveauEtudes(NiveauEtudes niveauEtudes) {
        this.niveauEtudes = niveauEtudes;
    }

    public String getEtablissementFrequente() {
        return etablissementFrequente;
    }
    public void setEtablissementFrequente(String etablissementFrequente) {
        this.etablissementFrequente = etablissementFrequente;
    }

    public Long getCoursChoisiId() {
        return coursChoisiId;
    }
    public void setCoursChoisiId(Long coursChoisiId) {
        this.coursChoisiId = coursChoisiId;
    }
    
    
    
    
    // Equals et HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EnfantDTO enfantDTO = (EnfantDTO) o;
        return Objects.equals(id, enfantDTO.id) && Objects.equals(nom, enfantDTO.nom) && Objects.equals(prenom, enfantDTO.prenom) && Objects.equals(dateDeNaissance, enfantDTO.dateDeNaissance) && niveauEtudes == enfantDTO.niveauEtudes && Objects.equals(etablissementFrequente, enfantDTO.etablissementFrequente) && Objects.equals(coursChoisiId, enfantDTO.coursChoisiId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nom, prenom, dateDeNaissance, niveauEtudes, etablissementFrequente, coursChoisiId);
    }

    // ToString
    @Override
    public String toString() {
        return "EnfantDTO{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", dateDeNaissance=" + dateDeNaissance +
                ", niveauEtudes=" + niveauEtudes +
                ", etablissementFrequente='" + etablissementFrequente + '\'' +
                ", coursChoisiId=" + coursChoisiId +
                '}';
    }
}