package encheres.emb.dao.jpa;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import encheres.emb.dao.IDaoEnchere;
import encheres.emb.data.Enchere;
import encheres.emb.data.Produit;
import encheres.emb.data.Utilisateur;

@ExtendWith(SpringExtension.class)
@SpringJUnitConfig(ConfigJpa.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestDaoEnchere {

	// Champs

	@Inject
	private EntityManager em;
	@Inject
	private IDaoEnchere dao;

	private int idProduit;
	private Enchere itemRef1;
	private Enchere itemRef2;
	private long itemCount1;

	// Initialisation

	@BeforeEach
	public void beforeEach() {

		idProduit = 3;

		var p3 = new Produit(3, null, null, null, null, null, false);
		var u4 = new Utilisateur(4, null, null, null, null, null, false, null);
		;
		itemRef1 = new Enchere(6, p3, u4, "490.00", "2024-01-01T10:33:00");

		var p1 = new Produit(1, null, null, null, null, null, false);
		var u1 = new Utilisateur(1, null, null, null, null, null, false, null);
		;
		itemRef2 = new Enchere(0, p1, u1, "99.99", "2024-01-01T00:00:00");

		itemCount1 = 6;

		UtilTest.initDb(em);
		em.clear();
	}

	// Tests

	@Test
	@Order(1)
	public void testRetrouver_OK() {
		// Récupère l'item dans la base
		var item = dao.retrouver(itemRef1.getId());
		assertNotNull(item);
		// Vérifie les données de l'item
		assertCompare(itemRef1, item);
	}

	@Test
	@Order(2)
	public void testRetrouver_Null() {
		// Item non trouvé dans la base
		var item = dao.retrouver(-1);
		assertNull(item);
	}

	@Test
	@Order(3)
	public void testInsererSupprimer() {
		var tx = em.getTransaction();
		try {
			tx.begin();
			// Insère un nouvel item
			itemRef2.setId(0);
			var id = dao.inserer(itemRef2);
			// Identifiant > 0 affecté au nouvel item
			assertTrue(id > 0);
			assertEquals(itemRef2.getId(), id);
			tx.commit();
		} catch (Throwable e) {
			if (tx.isActive())
				tx.rollback();
			throw e;
		}
		em.detach(itemRef2);
		try {
			// Récupère l'item dans la base
			var item = dao.retrouver(itemRef2.getId());
			assertNotNull(item);
			// Vérifie les données de l'item
			assertCompare(itemRef2, item);
			em.detach(item);
			// Supprime l'item de la base
			tx.begin();
			dao.supprimer(itemRef2.getId());
			tx.commit();
		} catch (Throwable e) {
			if (tx.isActive())
				tx.rollback();
			throw e;
		}
		// L'item ne peut pas être retrouvé car il est supprimé
		assertNull(dao.retrouver(itemRef2.getId()));
	}

	@Test
	@Order(4)
	public void testModifier() {
		var tx = em.getTransaction();
		// Enregistrement dans la base
		try {
			tx.begin();
			itemRef2.setId(itemRef1.getId());
			dao.modifier(itemRef2);
			tx.commit();
		} catch (Throwable e) {
			if (tx.isActive())
				tx.rollback();
			throw e;
		}
		em.detach(itemRef2);
		// Récupère l'item dans la base
		var item = dao.retrouver(itemRef2.getId());
		assertNotNull(item);
		// Vérifie les données de l'item
		assertCompare(itemRef2, item);
	}

	@Test
	@Order(5)
	public void testCompterPourProduit_OK() {
		var nbEncheres = dao.compterPourProduit(idProduit);
		assertEquals(itemCount1, nbEncheres);
	}

	@Test
	@Order(6)
	public void testCompterPourProduit_Zero() {
		var nbEncheres = dao.compterPourProduit(0);
		assertEquals(0, nbEncheres);
	}

	@Test
	@Order(7)
	public void testMeilleurePourProduit_OK() {
		var item = dao.meilleurePourProduit(idProduit);
		assertNotNull(item);
		assertCompare(itemRef1, item);
	}

	@Test
	@Order(8)
	public void testMeilleurePourProduit_null() {
		var item = dao.meilleurePourProduit(0);
		assertNull(item);
	}

	// Méthode auxilaire

	private void assertCompare(Enchere item1, Enchere item2) {
		assertEquals(item1.getId(), item2.getId());
		assertEquals(item1.getProduit().getId(), item2.getProduit().getId());
		assertEquals(item1.getUtilisateur().getId(), item2.getUtilisateur().getId());
		assertEquals(item1.getMontant(), item2.getMontant());
		assertEquals(item1.getDateHeure(), item2.getDateHeure());
	}

}
