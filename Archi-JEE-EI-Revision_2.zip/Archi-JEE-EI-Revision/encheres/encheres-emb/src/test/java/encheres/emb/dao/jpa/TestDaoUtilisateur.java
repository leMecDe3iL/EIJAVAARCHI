package encheres.emb.dao.jpa;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import encheres.emb.dao.IDaoUtilisateur;
import encheres.emb.data.Produit;
import encheres.emb.data.Utilisateur;

@ExtendWith(SpringExtension.class)
@SpringJUnitConfig(ConfigJpa.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestDaoUtilisateur {

	// Champs

	@Inject
	private EntityManager em;
	@Inject
	private IDaoUtilisateur dao;

	private Utilisateur itemRef1;
	private Utilisateur itemRef2;
	private long itemCount;

	// Initialisation

	@BeforeEach
	public void beforeEach() {
		itemRef1 = new Utilisateur(3, "ACHETEUR1", "a1", "a2@3il.fr", "a1", "a1", false, "300.00");
		;
		itemRef1.getProduits()
				.add(new Produit(6, itemRef1, "Clavier", "15.00", "2024-01-05T00:00:00", "2024-01-25T23:59:59", false));
		itemRef1.getProduits()
				.add(new Produit(5, itemRef1, "Souris", "8.00", "2024-01-06T00:00:00", "2024-01-26T23:59:59", false));

		itemRef2 = new Utilisateur(0, "Test", "test@3il.fr", "Test", "Test", "Test", false, "0.00");
		itemRef2.getProduits()
				.add(new Produit(0, itemRef2, "Livre", "10.00", "2024-01-04T04:04:04", "2024-01-27T07:07:07", true));
		itemRef2.getProduits()
				.add(new Produit(0, itemRef2, "Vélo", "400.00", "2024-01-05T05:05:05", "2024-01-28T08:08:08", false));

		itemCount = 4;
		UtilTest.initDb(em);
		em.clear();
	}

	// Tests

	@Test
	@Order(1)
	public void testRetrouver_OK() {
		// Récupère l'item dans la base
		var item = dao.retrouver(itemRef1.getId());
		assertNotNull(item);
		// Vérifie les données de l'item
		assertCompare(itemRef1, item);
	}

	@Test
	@Order(2)
	public void testRetrouver_Null() {
		// Item non trouvé dans la base
		var item = dao.retrouver(-1);
		assertNull(item);
	}

	@Test
	@Order(3)
	public void testRetrouver_Produits() {
		// Récupère l'item dans la base
		var item = dao.retrouver(itemRef1.getId());
		assertNotNull(item);
		// Vérifie les données de l'item
		assertCompare(itemRef1, item);
		assertCompareProduits(itemRef1, item);
	}

	@Test
	@Order(4)
	public void testModifier() {
		var tx = em.getTransaction();
		// Enregistrement dans la base
		try {
			tx.begin();
			itemRef2.setId(itemRef1.getId());
			dao.modifier(itemRef2);
			tx.commit();
		} catch (Throwable e) {
			if (tx.isActive())
				tx.rollback();
			throw e;
		}
		em.detach(itemRef2);
		// Récupère l'item dans la base
		var item = dao.retrouver(itemRef2.getId());
		assertNotNull(item);
		// Vérifie les données de l'item
		assertCompare(itemRef2, item);
	}

	@Test
	@Order(5)
	public void testInsererSupprimer() {
		var tx = em.getTransaction();
		try {
			tx.begin();
			// Insère un nouvel item
			itemRef2.setId(0);
			for (var p : itemRef2.getProduits()) {
				p.setId(0);
			}
			var id = dao.inserer(itemRef2);
			// Identifiant > 0 affecté au nouvel item
			assertTrue(id > 0);
			assertEquals(itemRef2.getId(), id);
			tx.commit();
		} catch (Throwable e) {
			if (tx.isActive())
				tx.rollback();
			throw e;
		}
		em.detach(itemRef2);
		try {
			// Récupère l'item dans la base
			var item = dao.retrouver(itemRef2.getId());
			assertNotNull(item);
			// Vérifie les données de l'item
			assertCompare(itemRef2, item);
			em.detach(item);
			// Supprime l'item de la base
			tx.begin();
			dao.supprimer(itemRef2.getId());
			tx.commit();
		} catch (Throwable e) {
			if (tx.isActive())
				tx.rollback();
			throw e;
		}
		// L'item ne peut pas être retrouvé car il est supprimé
		assertNull(dao.retrouver(itemRef2.getId()));
	}

	@Test
	@Order(6)
	public void testListerTout() {
		var liste = dao.listerTout();
		// Nombre d'items dans la liste
		assertEquals(itemCount, liste.size());
		// Identifiant du premier item de laliste
		assertEquals(itemRef1.getId(), liste.get(0).getId(), "Ordre de tri incorrect");
	}

	// Méthode auxilaire

	private void assertCompare(Utilisateur item1, Utilisateur item2) {
		assertEquals(item1.getId(), item2.getId());
		assertEquals(item1.getNom(), item2.getNom());
		assertEquals(item1.getPrenom(), item2.getPrenom());
		assertEquals(item1.getEmail(), item2.getEmail());
		assertEquals(item1.getPseudo(), item2.getPseudo());
		assertEquals(item1.getMotDePasse(), item2.getMotDePasse());
		assertEquals(item1.isFlagGestionnaire(), item2.isFlagGestionnaire());
		assertEquals(item1.getCredit(), item2.getCredit());
	}

	private void assertCompareProduits(Utilisateur item1, Utilisateur item2) {
		for (int i = 0; i < item1.getProduits().size(); ++i) {
			assertEquals(item1.getProduits().get(i).getNom(), item2.getProduits().get(i).getNom());
			assertEquals(item1.getProduits().get(i).getPrixMinimal(), item2.getProduits().get(i).getPrixMinimal());
			assertEquals(item1.getProduits().get(i).getDebutEncheres(), item2.getProduits().get(i).getDebutEncheres());
			assertEquals(item1.getProduits().get(i).getFinEncheres(), item2.getProduits().get(i).getFinEncheres());
			assertEquals(item1.getProduits().get(i).isFlagCloture(), item2.getProduits().get(i).isFlagCloture());
		}
	}

}
