package encheres.emb.dao.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Lazy;

@Lazy
@ComponentScan(basePackages = { "encheres.emb.dao.jpa", }, lazyInit = true)
public class ConfigJpa {

	@Bean
	public EntityManagerFactory emf() {
		return Persistence.createEntityManagerFactory(null);
	}

	@Bean
	public EntityManager em(EntityManagerFactory emf) {
		return emf.createEntityManager();
	}
}
