package encheres.emb.service.standard;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import encheres.commun.dto.DtoUtilisateur;
import encheres.commun.service.IServiceConnexion;
import encheres.emb.dao.IDaoConnexion;
import encheres.emb.data.mapper.IMapper;
import encheres.emb.service.util.IManagerSecurity;
import encheres.emb.service.util.UtilServices;

@Component
public class ServiceConnexion implements IServiceConnexion {

	// Champs

	@Inject
	private IManagerSecurity managerSecurity;
	@Inject
	private IMapper mapper;
	@Inject
	private IDaoConnexion daoConnexion;

	// Actions

	@Override
	public DtoUtilisateur sessionUtilisateurOuvrir(String pseudo, String motDePasse) {
		try {
			DtoUtilisateur utilisateur = mapper.map(daoConnexion.validerAuthentification(pseudo, motDePasse));
			managerSecurity.setUtilisateurActif(utilisateur);
			return utilisateur;
		} catch (Exception e) {
			throw UtilServices.exceptionAnomaly(e);
		}
	}

	@Override
	public void sessionUtilisateurFermer() {
		try {
			managerSecurity.setUtilisateurActif(null);
		} catch (Exception e) {
			throw UtilServices.exceptionAnomaly(e);
		}
	}

}
