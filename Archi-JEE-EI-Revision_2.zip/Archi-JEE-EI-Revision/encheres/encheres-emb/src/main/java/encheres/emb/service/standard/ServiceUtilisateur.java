package encheres.emb.service.standard;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import encheres.commun.dto.DtoUtilisateur;
import encheres.commun.exception.ExceptionValidation;
import encheres.commun.service.IServiceUtilisateur;
import encheres.emb.dao.IDaoUtilisateur;
import encheres.emb.dao.IManagerTransaction;
import encheres.emb.data.Utilisateur;
import encheres.emb.data.mapper.IMapper;
import encheres.emb.service.util.IManagerSecurity;
import encheres.emb.service.util.UtilServices;

@Component
public class ServiceUtilisateur implements IServiceUtilisateur {

	// Champs

	@Inject
	private IManagerSecurity managerSecurity;
	@Inject
	private IManagerTransaction managerTransaction;
	@Inject
	private IMapper mapper;
	@Inject
	private IDaoUtilisateur daoUtilisateur;
//	@Inject
//	private IDaoProduit			daoProduit;

	// Actions

	@Override
	public int inserer(DtoUtilisateur dtoUtilisateur) throws ExceptionValidation {
		try {

			managerSecurity.verifierAutorisationGestionnaire();
			verifierValiditeDonnees(dtoUtilisateur);

			managerTransaction.begin();
			int id = daoUtilisateur.inserer(mapper.map(dtoUtilisateur));
			managerTransaction.commit();
			return id;

		} catch (Exception e) {
			managerTransaction.rollbackSiApplicable();
			throw UtilServices.exceptionValidationOrAnomaly(e);
		}
	}

	@Override
	public void modifier(DtoUtilisateur dtoUtilisateur) throws ExceptionValidation {
		try {

			managerSecurity.verifierAutorisationGestionnaire();
			verifierValiditeDonnees(dtoUtilisateur);

			managerTransaction.begin();
			daoUtilisateur.modifier(mapper.map(dtoUtilisateur));
			managerTransaction.commit();

		} catch (Exception e) {
			managerTransaction.rollbackSiApplicable();
			throw UtilServices.exceptionValidationOrAnomaly(e);
		}
	}

	@Override
	public void supprimer(int idUtilisateur) throws ExceptionValidation {
		try {

			managerSecurity.verifierAutorisationGestionnaire();

//            if ( daoProduit.listerPourUtilisateur(idUtilisateur).size() != 0 ) {
//                throw new ExceptionValidation( "Des produits sont rattachés à cet utilisateur" );
//            }

			managerTransaction.begin();
			daoUtilisateur.supprimer(idUtilisateur);
			managerTransaction.commit();

		} catch (Exception e) {
			managerTransaction.rollbackSiApplicable();
			throw UtilServices.exceptionValidationOrAnomaly(e);
		}
	}

	@Override
	public DtoUtilisateur retrouver(int idUtilisateur) {
		try {

			managerSecurity.verifierAutorisationUtilisateur();
			return mapper.map(daoUtilisateur.retrouver(idUtilisateur));

		} catch (Exception e) {
			throw UtilServices.exceptionAnomaly(e);
		}
	}

	@Override
	public List<DtoUtilisateur> listerTout() {
		try {

			managerSecurity.verifierAutorisationUtilisateur();
			List<DtoUtilisateur> liste = new ArrayList<>();
			for (Utilisateur categorie : daoUtilisateur.listerTout()) {
				liste.add(mapper.map(categorie));
			}
			return liste;

		} catch (Exception e) {
			throw UtilServices.exceptionAnomaly(e);
		}
	}

	// Méthodes auxiliaires

	private void verifierValiditeDonnees(DtoUtilisateur dtoUtilisateur) throws ExceptionValidation {

		StringBuilder message = new StringBuilder();

		if (dtoUtilisateur.getNom() == null || dtoUtilisateur.getNom().isEmpty()) {
			message.append("\nLe nom est obligatoire.");
		} else if (dtoUtilisateur.getNom().length() > 25) {
			message.append("\nLe nom est trop long.");
		}

		if (dtoUtilisateur.getPrenom() == null || dtoUtilisateur.getPrenom().isEmpty()) {
			message.append("\nLe prénom est obligatoire.");
		} else if (dtoUtilisateur.getPrenom().length() > 25) {
			message.append("\nLe prénom est trop long.");
		}

		if (dtoUtilisateur.getEmail() == null || dtoUtilisateur.getEmail().isEmpty()) {
			message.append("\nL'adresse e-mail est obligatoire.");
		} else if (dtoUtilisateur.getEmail().length() > 50) {
			message.append("\nL'adresse e-mail est trop longue.");
		} else if (!dtoUtilisateur.getEmail().matches(
				"(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\\.){3}(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9])|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])")) {
			message.append("\nAadresse e-mail incorrecte.");
		}

		if (dtoUtilisateur.getPseudo() == null || dtoUtilisateur.getPseudo().isEmpty()) {
			message.append("\nLe pseudo est obligatoire.");
		} else if (dtoUtilisateur.getPseudo().length() > 25) {
			message.append("\nLe pseudo est trop long.");
		}

		if (dtoUtilisateur.getMotDePasse() == null || dtoUtilisateur.getMotDePasse().isEmpty()) {
			message.append("\nLe met de passe est obligatoire.");
		} else if (dtoUtilisateur.getMotDePasse().length() > 25) {
			message.append("\nLe met de passe est trop long.");
		}

		if (message.length() > 0) {
			throw new ExceptionValidation(message.toString().substring(1));
		}
	}

}
