package encheres.emb.dao.jpa;

import javax.activation.DataSource;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;

import encheres.emb.dao.IDaoEnchere;
import encheres.emb.dao.IDaoProduit;
import encheres.emb.dao.IDaoUtilisateur;
import encheres.emb.data.Enchere;

@Component
public class DaoEnchere implements IDaoEnchere {

	@Inject
	private EntityManager em;
	

	private DataSource		dataSource;
	
	private IDaoProduit		daoProduit;
	
	private IDaoUtilisateur	daoUtilisateur;

	public int inserer(Enchere enchere) {
		em.persist(enchere);
		em.flush(); 
		return enchere.getId();
	}

	public void modifier(Enchere enchere) {
		em.merge(enchere);
	}

	public void supprimer(int id) {
		Enchere enchere = em.find(Enchere.class, id);
		if (enchere != null) {
			em.remove(enchere);
		}
	}

	public Enchere retrouver(int id) {
		return em.find(Enchere.class, id);
	}

	public int compterPourProduit(int produitId) {
		String jpql = "SELECT COUNT(e) FROM Enchere e WHERE e.produit.id = :produitId";
		TypedQuery<Long> query = em.createQuery(jpql, Long.class);
		query.setParameter("produitId", produitId);
		return query.getSingleResult().intValue();
	}

	
	public Enchere meilleurePourProduit(int produitId) {

		String jpql = "SELECT e FROM Enchere e WHERE e.produit.id = :produitId ORDER BY e.dateHeure DESC";
		TypedQuery<Enchere> query = em.createQuery(jpql, Enchere.class);
		query.setParameter("produitId", produitId);
		query.setMaxResults(1);
		try {
			return query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}

	}
}
