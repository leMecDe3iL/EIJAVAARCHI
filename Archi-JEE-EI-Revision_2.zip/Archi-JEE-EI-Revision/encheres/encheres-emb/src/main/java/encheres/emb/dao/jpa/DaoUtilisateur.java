package encheres.emb.dao.jpa;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;

import encheres.emb.dao.IDaoUtilisateur;
import encheres.emb.data.Utilisateur;

@Component
public class DaoUtilisateur implements IDaoUtilisateur {

	@Inject
	private EntityManager em;

	// Actions

	@Override
	public int inserer(Utilisateur utilisateur) {
		 em.persist(utilisateur);
	        em.flush(); // Ensure the ID is generated
	        return utilisateur.getId();
	}

	@Override
	public void modifier(Utilisateur utilisateur) {
		em.merge(utilisateur);
	}

	@Override
	public void supprimer(int idUtilisateur) {
		Utilisateur utilisateur = retrouver(idUtilisateur);
		if (utilisateur != null) {
			em.remove(utilisateur);
		}
	}

	@Override
	public Utilisateur retrouver(int idUtilisateur) {
		return em.find(Utilisateur.class, idUtilisateur);
	}

	@Override
	public List<Utilisateur> listerTout() {
		TypedQuery<Utilisateur> query = em.createQuery("SELECT u FROM Utilisateur u ORDER BY u.nom ASC, u.prenom ASC",
				Utilisateur.class);
		return query.getResultList();
	}

}
