package encheres.emb.data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "enchere")
public class Enchere {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idenchere")
	private int id;

	@ManyToOne
	@JoinColumn(name = "idproduit")
	private Produit produit;

	@ManyToOne
	@JoinColumn(name = "idutilisateur")
	private Utilisateur utilisateur;

	private BigDecimal montant;
	private LocalDateTime dateHeure;

	// Getters & Setters

	public int getId() {
		return id;
	}

	public void setId(int idEnchere) {
		this.id = idEnchere;
	}

	public Produit getProduit() {
		return produit;
	}

	public void setProduit(Produit produit) {
		this.produit = produit;
	}

	public Utilisateur getUtilisateur() {
		return utilisateur;
	}

	public void setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}

	public BigDecimal getMontant() {
		return montant;
	}

	public void setMontant(BigDecimal montant) {
		this.montant = montant;
	}

	public LocalDateTime getDateHeure() {
		return dateHeure;
	}

	public void setDateHeure(LocalDateTime dateHeure) {
		this.dateHeure = dateHeure;
	}

	// hashCode() & equals()

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Enchere))
			return false;
		Enchere other = (Enchere) obj;
		return id == other.id;
	}

	// Constructeurs

	public Enchere() {
	}

	public Enchere(int id, Produit produit, Utilisateur utilisateur, String montant, String dateHeure) {
		this.id = id;
		this.produit = produit;
		this.utilisateur = utilisateur;
		this.montant = montant == null ? null : new BigDecimal(montant);
		this.dateHeure = dateHeure == null ? null : LocalDateTime.parse(dateHeure);
	}

}
