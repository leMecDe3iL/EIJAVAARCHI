package encheres.emb.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Table(name = "produit")
public class Produit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idproduit")
	private int id;

	@ManyToOne
	@JoinColumn(name = "idutilisateur")
	private Utilisateur utilisateur;

	private String nom;
	private BigDecimal prixMinimal;
	private LocalDateTime debutEncheres;
	private LocalDateTime finEncheres;
	private boolean flagCloture;
	// Getters & Setters

	public int getId() {
		return id;
	}

	public void setId(int idProduit) {
		this.id = idProduit;
	}

	public Utilisateur getUtilisateur() {
		return utilisateur;
	}

	public void setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public BigDecimal getPrixMinimal() {
		return prixMinimal;
	}

	public void setPrixMinimal(BigDecimal prixMinimal) {
		this.prixMinimal = prixMinimal;
	}

	public LocalDateTime getDebutEncheres() {
		return debutEncheres;
	}

	public void setDebutEncheres(LocalDateTime ebutEnchere) {
		this.debutEncheres = ebutEnchere;
	}

	public LocalDateTime getFinEncheres() {
		return finEncheres;
	}

	public void setFinEncheres(LocalDateTime finEnchere) {
		this.finEncheres = finEnchere;
	}

	public boolean isFlagCloture() {
		return flagCloture;
	}

	public void setFlagCloture(boolean flagCloture) {
		this.flagCloture = flagCloture;
	}

	// hashCode() & equals()

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Produit))
			return false;
		Produit other = (Produit) obj;
		return id == other.id;
	}

	// Constructeurs

	public Produit() {
	}

	public Produit(int id, Utilisateur utilisateur, String nom, String prixMinimal, String debutEncheres,
			String finEncheres, boolean flagCloture) {
		this.id = id;
		this.utilisateur = utilisateur;
		this.nom = nom;
		this.prixMinimal = prixMinimal == null ? null : new BigDecimal(prixMinimal);
		this.debutEncheres = debutEncheres == null ? null : LocalDateTime.parse(debutEncheres);
		this.finEncheres = finEncheres == null ? null : LocalDateTime.parse(finEncheres);
		this.flagCloture = flagCloture;
	}

}
