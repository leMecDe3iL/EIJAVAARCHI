package encheres.emb.dao.jpa;

import java.time.LocalDateTime;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;

import encheres.emb.dao.IDaoProduit;
import encheres.emb.data.Produit;
import encheres.emb.data.Utilisateur;

@Component
public class DaoProduit implements IDaoProduit {
	@Inject
	private EntityManager em;

	@Override
	public int inserer(Produit produit) {
		em.persist(produit);
		em.flush();
		return produit.getId();
	}

	public void modifier(Produit produit) {
		em.merge(produit);
	}

	@Override
	public void supprimer(int idProduit) {
		Produit produit = retrouver(idProduit);
		if (produit != null) {
			em.remove(produit);
		}
	}

	@Override
	public Produit retrouver(int idProduit) {
		return em.find(Produit.class, idProduit);
	}

	@Override
	public List<Produit> listerPourUtilisateur(int utilisateurId) {
		return em.find(Utilisateur.class, utilisateurId).getProduits();
	}

	public List<Produit> listerAVendre(LocalDateTime dateHeure) {
		String jpql = "SELECT p FROM Produit p WHERE p.finEncheres IS NOT NULL AND p.finEncheres >= :dateHeure ORDER BY p.finEncheres";
		TypedQuery<Produit> query = em.createQuery(jpql, Produit.class);
		query.setParameter("dateHeure", dateHeure);
		return query.getResultList();
	}
}
