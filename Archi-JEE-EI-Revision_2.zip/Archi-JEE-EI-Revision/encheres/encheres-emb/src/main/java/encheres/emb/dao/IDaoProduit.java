package encheres.emb.dao;

import java.time.LocalDateTime;
import java.util.List;

import encheres.emb.data.Produit;

public interface IDaoProduit {

	int inserer(Produit produit);

	void modifier(Produit produit);

	void supprimer(int idProduit);

	Produit retrouver(int idProduit);

	List<Produit> listerPourUtilisateur(int idUtilisateur);

	List<Produit> listerAVendre(LocalDateTime dateHeure);

}