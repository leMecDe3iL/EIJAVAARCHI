package encheres.emb.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "utilisateur")
public class Utilisateur {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idutilisateur")
	private int id;

	private String nom;
	private String prenom;
	private String email;
	private String pseudo;
	private String motDePasse;

	@Column(name = "flaggest")
	private boolean flagGestionnaire;

	private BigDecimal credit;

	@OneToMany(mappedBy = "utilisateur")
	@OrderBy("nom ASC")
	private List<Produit> produits;

	// Getters & Setters

	public int getId() {
		return id;
	}

	public void setId(int idUtilisateur) {
		this.id = idUtilisateur;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPseudo() {
		return pseudo;
	}

	public void setPseudo(String pseudo) {
		this.pseudo = pseudo;
	}

	public String getMotDePasse() {
		return motDePasse;
	}

	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}

	public BigDecimal getCredit() {
		return credit;
	}

	public void setCredit(BigDecimal credit) {
		this.credit = credit;
	}

	public boolean isFlagGestionnaire() {
		return flagGestionnaire;
	}

	public void setFlagGestionnaire(boolean flagGestionnaire) {
		this.flagGestionnaire = flagGestionnaire;
	}

	public List<Produit> getProduits() {
		return produits;
	}

	public void setProduits(List<Produit> produits) {
		this.produits = produits;
	}

	// hashCode() & equals()

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Utilisateur))
			return false;
		Utilisateur other = (Utilisateur) obj;
		return id == other.id;
	}

	// Constructeurs

	public Utilisateur() {
	}

	public Utilisateur(int id, String nom, String prenom, String email, String pseudo, String motDePasse,
			boolean flagGestionnaire, String credit) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.pseudo = pseudo;
		this.motDePasse = motDePasse;
		this.flagGestionnaire = flagGestionnaire;
		this.credit = credit == null ? null : new BigDecimal(credit);
		this.produits = new ArrayList<>();
	}

}
