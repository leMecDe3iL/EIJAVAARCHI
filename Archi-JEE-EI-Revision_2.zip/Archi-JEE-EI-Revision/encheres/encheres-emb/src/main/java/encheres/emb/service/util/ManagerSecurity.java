package encheres.emb.service.util;

import java.io.Serializable;

import javax.inject.Named;

import org.springframework.stereotype.Component;

import encheres.commun.dto.DtoUtilisateur;
import jfox.exception.ExceptionPermission;

@Component
@SuppressWarnings("serial")
public class ManagerSecurity implements IManagerSecurity, Serializable {

	// Champs

	@Named
	protected DtoUtilisateur utilisateurActif;

	// Getters & Setters

	@Override
	public void setUtilisateurActif(DtoUtilisateur utilisateurActif) {
		this.utilisateurActif = utilisateurActif;
	}

	@Override
	public int getIdUtilisateurActif() {
		return utilisateurActif.getId();
	}

	// Actions

	// Vérifie que le utilisateur connecté a le rôle utilisateur (ou à défaut
	// administrateur)
	@Override
	public void verifierAutorisationUtilisateur() throws ExceptionPermission {
		if (utilisateurActif == null) {
			throw new ExceptionPermission();
		}
	}

	// Vérifie que le utilisateur connecté a le rôle administrateur
	@Override
	public void verifierAutorisationGestionnaire() throws ExceptionPermission {
		if (utilisateurActif == null || !utilisateurActif.isFlagGestionnaire()) {
			throw new ExceptionPermission();
		}
	}

	// Vérifie que le utilisateur connecte, soit a le rôle administrateur
	// soit a comme identifiant celui passé en paramètre
	@Override
	public void verifierAutorisationGestionnaireOuUtilisateurActif(int idUtilisateur) throws ExceptionPermission {
		if (utilisateurActif == null
				|| (!utilisateurActif.isFlagGestionnaire() && utilisateurActif.getId() != idUtilisateur)) {
			throw new ExceptionPermission();
		}
	}

}
