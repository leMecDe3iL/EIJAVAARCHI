package encheres.emb.service.util;

import encheres.commun.dto.DtoUtilisateur;
import jfox.exception.ExceptionPermission;

public interface IManagerSecurity {

	int getIdUtilisateurActif();

	void verifierAutorisationUtilisateur() throws ExceptionPermission;

	void verifierAutorisationGestionnaire() throws ExceptionPermission;

	void verifierAutorisationGestionnaireOuUtilisateurActif(int idUtilisateur) throws ExceptionPermission;

	void setUtilisateurActif(DtoUtilisateur utilisateurActif);

}