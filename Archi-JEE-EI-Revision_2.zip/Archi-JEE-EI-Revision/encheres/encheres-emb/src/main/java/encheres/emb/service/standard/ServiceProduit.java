package encheres.emb.service.standard;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import encheres.commun.dto.DtoProduit;
import encheres.commun.exception.ExceptionValidation;
import encheres.commun.service.IServiceProduit;
import encheres.emb.dao.IDaoEnchere;
import encheres.emb.dao.IDaoProduit;
import encheres.emb.dao.IManagerTransaction;
import encheres.emb.data.Enchere;
import encheres.emb.data.Produit;
import encheres.emb.data.mapper.IMapper;
import encheres.emb.service.util.IManagerSecurity;
import encheres.emb.service.util.UtilServices;

@Component
public class ServiceProduit implements IServiceProduit {

	// Champs

	@Inject
	private IManagerSecurity managerSecurity;
	@Inject
	private IManagerTransaction managerTransaction;
	@Inject
	private IMapper mapper;
	@Inject
	private IDaoProduit daoProduit;
	@Inject
	private IDaoEnchere daoEnchere;

	// Actions

	@Override
	public int inserer(DtoProduit dtoProduit) throws ExceptionValidation {
		try {

			managerSecurity.verifierAutorisationGestionnaire();
			verifierValiditeDonnees(dtoProduit);

			managerTransaction.begin();
			int id = daoProduit.inserer(mapper.map(dtoProduit));
			managerTransaction.commit();
			return id;

		} catch (Exception e) {
			managerTransaction.rollbackSiApplicable();
			throw UtilServices.exceptionValidationOrAnomaly(e);
		}
	}

	@Override
	public void modifier(DtoProduit dtoProduit) throws ExceptionValidation {
		try {

			managerSecurity.verifierAutorisationGestionnaire();
			verifierValiditeDonnees(dtoProduit);

			managerTransaction.begin();
			daoProduit.modifier(mapper.map(dtoProduit));
			managerTransaction.commit();

		} catch (Exception e) {
			managerTransaction.rollbackSiApplicable();
			throw UtilServices.exceptionValidationOrAnomaly(e);
		}
	}

	@Override
	public void supprimer(int idProduit) throws ExceptionValidation {
		try {

			managerSecurity.verifierAutorisationGestionnaire();

			if (daoEnchere.compterPourProduit(idProduit) != 0) {
				throw new ExceptionValidation("Des produits sont rattachés à cet produit");
			}

			managerTransaction.begin();
			daoProduit.supprimer(idProduit);
			managerTransaction.commit();

		} catch (Exception e) {
			managerTransaction.rollbackSiApplicable();
			throw UtilServices.exceptionValidationOrAnomaly(e);
		}
	}

	@Override
	public DtoProduit retrouver(int idProduit) {
		try {

//			managerSecurity.verifierAutorisationGestionnaireOuUtilisateurActif();
			return map(daoProduit.retrouver(idProduit));

		} catch (Exception e) {
			throw UtilServices.exceptionAnomaly(e);
		}
	}

	@Override
	public List<DtoProduit> listerAVendre(LocalDateTime dateHeure) {
		try {

//			managerSecurity.verifierAutorisationProduit();
			List<DtoProduit> liste = new ArrayList<>();
			for (Produit item : daoProduit.listerAVendre(dateHeure)) {
				liste.add(map(item));
			}
			return liste;

		} catch (Exception e) {
			throw UtilServices.exceptionAnomaly(e);
		}
	}

	@Override
	public List<DtoProduit> listerAVendre(int idUtilisateur) {
		try {

//			managerSecurity.verifierAutorisationProduit();
			List<DtoProduit> liste = new ArrayList<>();
			for (Produit item : daoProduit.listerPourUtilisateur(idUtilisateur)) {
				liste.add(mapper.map(item));
			}
			return liste;

		} catch (Exception e) {
			throw UtilServices.exceptionAnomaly(e);
		}
	}

	// Méthodes auxiliaires

	private DtoProduit map(Produit produit) {

		DtoProduit dto = mapper.map(produit);

		Enchere enchere = daoEnchere.meilleurePourProduit(produit.getId());
		if (enchere == null) {
			dto.setMeilleureOffre(dto.getPrixMinimal());
			dto.setNbEncheres(0);
		} else {
			dto.setMeilleureOffre(enchere.getMontant());
			dto.setNbEncheres(daoEnchere.compterPourProduit(produit.getId()));
		}
		return dto;
	}

	private void verifierValiditeDonnees(DtoProduit dtoProduit) throws ExceptionValidation {

		StringBuilder message = new StringBuilder();

		if (dtoProduit.getUtilisateur() == null) {
			message.append("\nL'utilisateur est obligatoire.");
		}

		if (dtoProduit.getNom() == null || dtoProduit.getNom().isEmpty()) {
			message.append("\nLe nom est obligatoire.");
		} else if (dtoProduit.getNom().length() < 3) {
			message.append("\nLe nom est trop court.");
		} else if (dtoProduit.getNom().length() > 25) {
			message.append("\nLe nom est trop long.");
		}

		if (dtoProduit.getPrixMinimal() == null) {
			message.append("\nLe prix minimal est obligatoire.");
		} else if (dtoProduit.getPrixMinimal().doubleValue() < 0) {
			message.append("\nLe prix minimal doit être supérieur ou égal à zéro.");
		}

		if (message.length() > 0) {
			throw new ExceptionValidation(message.toString().substring(1));
		}
	}

}
