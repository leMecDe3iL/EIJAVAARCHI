package encheres.emb.dao.jdbc2;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.stereotype.Component;

import encheres.emb.dao.IDaoConnexion;
import encheres.emb.data.Utilisateur;
import jfox.jdbc.UtilJdbc;

@Component
public class DaoConnexion implements IDaoConnexion {

	// Champs

	@Inject
	private DataSource dataSource;

	// Actions

	@Override
	public Utilisateur validerAuthentification(String pseudo, String motDePasse) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			sql = "SELECT * FROM utilisateur WHERE Pseudo = ? AND MotDePasse = ?";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, pseudo);
			stmt.setObject(2, motDePasse);
			rs = stmt.executeQuery();

			if (rs.next()) {
				return construireUtilisateur(rs);
			} else {
				return null;
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}
	}

	@Override
	public boolean verifierUnicitePseudo(String pseudo, int idUtilisateur) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			sql = "SELECT COUNT(*) AS nbUtilisateurs" + " FROM utilisateur WHERE Pseudo = ? AND IdUtilisateur <> ?";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, pseudo);
			stmt.setObject(2, idUtilisateur);
			rs = stmt.executeQuery();

			rs.next();
			return rs.getInt("nbUtilisateurs") == 0;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}
	}

	// Méthodes auxiliaires

	private Utilisateur construireUtilisateur(ResultSet rs) throws SQLException {
		var item = new Utilisateur();
		item.setId(rs.getObject("IdUtilisateur", Integer.class));
		item.setNom(rs.getObject("nom", String.class));
		item.setPrenom(rs.getObject("prenom", String.class));
		item.setEmail(rs.getObject("email", String.class));
		item.setPseudo(rs.getObject("pseudo", String.class));
		item.setMotDePasse(rs.getObject("motdepasse", String.class));
		item.setFlagGestionnaire(rs.getObject("flagGest", Boolean.class));
		item.setCredit(rs.getObject("credit", BigDecimal.class));
		return item;
	}

}
