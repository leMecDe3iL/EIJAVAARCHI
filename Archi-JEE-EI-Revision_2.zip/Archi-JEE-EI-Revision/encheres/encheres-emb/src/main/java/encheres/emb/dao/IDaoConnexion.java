package encheres.emb.dao;

import encheres.emb.data.Utilisateur;

public interface IDaoConnexion {

	Utilisateur validerAuthentification(String pseudo, String motDePasse);

	boolean verifierUnicitePseudo(String pseudo, int idUtilisateur);

}