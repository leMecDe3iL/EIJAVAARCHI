package encheres.gui.view.encheres;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.inject.Inject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import encheres.gui.data.Produit;
import encheres.gui.model.IModelProduitEnVente;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import jfox.javafx.util.UtilFX;
import jfox.javafx.view.ControllerAbstract;
import jfox.javafx.view.IManagerGui;
import jfox.javafx.view.Mode;


@Component
@Scope( "prototype")
public class ViewProduitEnVenteListe extends ControllerAbstract  {
	
	
	// Composants de la vue
	
	@FXML
	private TableView<Produit>	tbvProduits;
	@FXML
	private TableColumn<Produit, String> colNom;
	@FXML
	private TableColumn<Produit, BigDecimal> colMontant;
	@FXML
	private TableColumn<Produit, LocalDateTime> colDebut;
	@FXML
	private TableColumn<Produit, LocalDateTime> colFin;
	@FXML
	private Button				btnDetails;
	
	
	// Autres champs
	
	@Inject
	private IManagerGui			managerGui;
	@Inject
	private IModelProduitEnVente	modelProduit;
	
	
	// Initialisation du controller

	@FXML
	private void initialize() {
		
		// TableView
		tbvProduits.setItems( modelProduit.getList() );
		UtilFX.setValueFactory( colNom, "nom" );
		UtilFX.setValueFactory( colMontant, "meilleureOffre" );
		UtilFX.setValueFactory( colDebut, "debutEncheres" );
		UtilFX.setCellFactory( colDebut, d -> d.format( DateTimeFormatter.ofPattern("dd/MM/yyyy")) );
		UtilFX.setValueFactory( colFin, "finEncheres" );
		UtilFX.setCellFactory( colFin, d -> d.format( DateTimeFormatter.ofPattern("dd/MM/yyyy")) );
		bindBidirectional( tbvProduits, modelProduit.currentProperty(), modelProduit.flagRefreshingListProperty() );
		
		// Configuraiton des boutons
		tbvProduits.getSelectionModel().selectedItemProperty().addListener(obs -> {
			configurerBoutons();
		});
    	configurerBoutons();
	}

	
	@Override
	public void refresh() {
		modelProduit.refreshList();
		tbvProduits.requestFocus();
	}
	
	
	// Actions
	
	@FXML
	private void doDetails() {
		modelProduit.initDraft( Mode.DISPLAy );;
		managerGui.showView( ViewProduitEnVenteForm.class );
	}
	
	
	// Gestion des évènements

	// Clic sur la liste
	@FXML
	private void gererClicSurListe( MouseEvent event ) {
		if (event.getButton().equals(MouseButton.PRIMARY)) {
			if (event.getClickCount() == 2) {
				if ( tbvProduits.getSelectionModel().getSelectedIndex() == -1 ) {
					managerGui.showDialogError( "Aucun élément n'est sélectionné dans la liste.");
				} else {
					doDetails();
				}
			}
		}
	}

	
	// Méthodes auxiliaires
	
	private void configurerBoutons() {
		var flagDisable = tbvProduits.getSelectionModel().getSelectedItem() == null;
		btnDetails.setDisable(flagDisable);
	}
	
}
