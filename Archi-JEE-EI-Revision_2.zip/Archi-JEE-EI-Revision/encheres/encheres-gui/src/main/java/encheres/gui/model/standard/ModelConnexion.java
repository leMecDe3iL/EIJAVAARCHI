package encheres.gui.model.standard;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import encheres.commun.dto.DtoUtilisateur;
import encheres.commun.exception.ExceptionValidation;
import encheres.commun.service.IServiceConnexion;
import encheres.gui.data.Utilisateur;
import encheres.gui.data.mapper.IMapperGui;
import encheres.gui.model.IModelConnexion;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import jfox.javafx.util.UtilFX;


@Component
public class ModelConnexion implements IModelConnexion {
	
	// Logger
	private static final Logger logger = Logger.getLogger( ModelConnexion.class.getName() );
	
	
	// Données observables 
	
	// Vue connexion
	private final Utilisateur		draft = new Utilisateur();

	// Utilisateur connecté
	private final ObjectProperty<Utilisateur>	utilisateurActif = new SimpleObjectProperty<>();

	
	// Autres champs
	@Inject
	private IMapperGui			mapper;
	@Inject @Lazy
	private IServiceConnexion	serviceConnexion;
	

	// Getters 
	
	@Override
	public Utilisateur getDraft() {
		return draft;
	}
	
	@Override
	public ObjectProperty<Utilisateur> utilisateurActifProperty() {
		return utilisateurActif;
	}
	
	@Override
	public Utilisateur getUtilisateurActif() {
		return utilisateurActif.get();
	}
	
	
	// Initialisation
	
	@PostConstruct
	public void init() {
		draft.setPseudo( "admin" );
		draft.setMotDePasse( "admin" );
	}
	
	
	// Actions


	@Override
	public void ouvrirSessionUtilisateur() {
		
		try {

			DtoUtilisateur dto = serviceConnexion.sessionUtilisateurOuvrir(
					draft.pseudoProperty().get(), draft.motDePasseProperty().get() );
			
			// Message de log
			String logMessage;
			if( dto == null ) {
				logMessage = "Pseudo ou mot de passe invalide : " + draft.pseudoProperty().get() + " / " + draft.motDePasseProperty().get();
			} else {
				logMessage = "\n    Utilisateur connecté : " + dto.getId() +  " " + dto.getPseudo();
				logMessage += "\n    Roles : Utilisateur";
				if( dto.isFlagGestionnaire() ) {
					logMessage += ", Gestionnaier";
				}
			}
			logger.log( Level.CONFIG, logMessage );
			
			if( dto == null ) {
				throw new ExceptionValidation( "Pseudo ou mot de passe invalide." );
			} else {
				 Platform.runLater( () -> utilisateurActif.set( mapper.map( dto ) ) );
			}
		} catch ( Exception e) {
			throw UtilFX.runtimeException( e );
		}
	}
	

	@Override
	public void fermerSessionUtilisateur() {
		serviceConnexion.sessionUtilisateurFermer();
		utilisateurActif.set( null );
	}

}
