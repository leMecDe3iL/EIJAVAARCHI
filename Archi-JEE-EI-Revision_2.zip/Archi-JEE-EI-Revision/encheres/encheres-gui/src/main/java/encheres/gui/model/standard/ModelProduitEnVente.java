package encheres.gui.model.standard;


import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import encheres.commun.dto.DtoEnchere;
import encheres.commun.dto.DtoProduit;
import encheres.commun.service.IServiceEnchere;
import encheres.commun.service.IServiceProduit;
import encheres.gui.data.Produit;
import encheres.gui.data.mapper.IMapperGui;
import encheres.gui.model.IModelConnexion;
import encheres.gui.model.IModelProduitEnVente;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jfox.javafx.util.UtilFX;
import jfox.javafx.view.Mode;


@Component
public class ModelProduitEnVente implements IModelProduitEnVente {
	
	
	// Données observables 
	
	private final ObservableList<Produit> list = FXCollections.observableArrayList(); 
	
	private final BooleanProperty 		flagRefreshingList = new SimpleBooleanProperty();
	
	private final Produit				draft 		= new Produit();
	
	private final ObjectProperty<Produit> current 	= new SimpleObjectProperty<>();
	
	private final ObjectProperty<BigDecimal> montantEnchere = new SimpleObjectProperty<>(); 
	
	
	// Autres champs
	
	private Mode			mode;

    @Inject
	private IMapperGui		mapper;
    @Inject
	private IServiceProduit	serviceProduit;
    @Inject
	private IServiceEnchere	serviceEnchere;
    @Inject
    private IModelConnexion	modelConnexion;
	
	
	// Getters & Setters
	
    @Override
	public ObservableList<Produit> getList() {
		return list;
	}

    @Override
	public BooleanProperty flagRefreshingListProperty() {
		return flagRefreshingList;
	}
	
    @Override
	public Produit getDraft() {
		return draft;
	}

    @Override
	public ObjectProperty<Produit> currentProperty() {
		return current;
	}

    @Override
	public Produit getCurrent() {
		return current.getValue();
	}

    @Override
	public void setCurrent(Produit item) {
		current.setValue(item);
	}

    @Override
	public ObjectProperty<BigDecimal> montantEnchereProperty() {
		return montantEnchere;
	}
	
    @Override
	public Mode getMode() {
		return mode;
	}
    
    @Override
    public LocalDateTime getNow() {
    	return LocalDateTime.parse( "2024-01-10T12:00:00" );
    }
	
	
	// Actions
	
    @Override
	public void refreshList() {
		// flagRefreshingList vaut true pendant la durée  
		// du traitement de mise à jour de la liste
		flagRefreshingList.set(true);
		list.clear();
		var dateHeure = getNow();
		for( DtoProduit dto : serviceProduit.listerAVendre( dateHeure ) ) {
			var item = mapper.map( dto );
			list.add( item );
		}
		flagRefreshingList.set(false);
 	}

	
    @Override
	public void initDraft(Mode mode) {
		this.mode = mode;
		if( mode == Mode.NEW ) {
			mapper.update( draft, new Produit() );
		} else {
			setCurrent( mapper.map( serviceProduit.retrouver( getCurrent().getId() ) ) );
			mapper.update( draft, getCurrent() );
			montantEnchere.set(null);
		}
	}
	
	
    @Override
	public void saveEnchere() {
		
		try {
			
			// Enregistre les données dans la base
			
			DtoEnchere	dto = new DtoEnchere();
			dto.setProduit( mapper.map( current.get() ) );
			dto.setUtilisateur( mapper.map( modelConnexion.getUtilisateurActif() ) );
			dto.setMontant( montantEnchere.get() );
			dto.setDateHeure(  LocalDateTime.now() );
			
			// Insertion
			draft.setId( serviceEnchere.inserer( dto ) );
			// Actualise le courant
			setCurrent( mapper.update( new Produit(), draft ) );

		} catch ( Exception e) {
			throw UtilFX.runtimeException( e );
		}
	}

}
