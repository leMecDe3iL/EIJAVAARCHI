package encheres.gui.view.encheres;

import java.math.BigDecimal;

import javax.inject.Inject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import encheres.gui.model.IModelProduitEnVente;
import javafx.beans.binding.Bindings;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import jfox.javafx.util.converter.ConverterBigDecimal;
import jfox.javafx.util.converter.ConverterInteger;
import jfox.javafx.util.converter.ConverterLocalDateTime;
import jfox.javafx.view.ControllerAbstract;
import jfox.javafx.view.IManagerGui;


@Component
@Scope( "prototype")
public class ViewProduitEnVenteForm extends ControllerAbstract  {
	
	
	// Composants de la vue
	
	@FXML
	private Label				labNom;
	@FXML
	private Label				labVendeur;
	@FXML
	private Label				labDebutEcheres;
	@FXML
	private Label				labFinEncheres;
	@FXML
	private Label				labPrixInitial;
	@FXML
	private Label				labMeilleureOffre;
	@FXML
	private Label				labNbEncheres;
	@FXML
	private TextField			txfMontantEchere;
	@FXML
	private Button				btnEncherir;

	
	// Autres champs
	@Inject
	private IManagerGui			managerGui;
	@Inject
	private IModelProduitEnVente	modellProduitEnVente;
    
	
	// Initialisation du controller
	
	public void initialize() {

		var draft = modellProduitEnVente.getDraft();
		
		bind( labNom, draft.nomProperty() );
		bind( labVendeur, Bindings.createStringBinding( () -> draft.getUtilisateur().getNom() + " " + draft.getUtilisateur().getPrenom(), draft.utilisateurProperty()  ) );
		bind( labDebutEcheres, draft.debutEncheresProperty(), new ConverterLocalDateTime( "dd/MM/yyyy hh:mm:ss" ) );
		bind( labFinEncheres, draft.finEncheresProperty(), new ConverterLocalDateTime( "dd/MM/yyyy hh:mm:ss" ) );
		bind( labPrixInitial, draft.prixMinimalProperty(), new ConverterBigDecimal( "#,##0.00 €" ) );
		bind( labMeilleureOffre, draft.meilleureOffreProperty(), new ConverterBigDecimal( "#,##0.00 €" ) );
		bind( labNbEncheres, draft.nbEncheresProperty(), new ConverterInteger() );
		
		bindBidirectional( txfMontantEchere, modellProduitEnVente.montantEnchereProperty(), new ConverterBigDecimal() );
		validator.addRuleNotBlank( txfMontantEchere );
		validator.addRuleMinValue( txfMontantEchere, new BigDecimal( "0.00") );
		validator.addRule( txfMontantEchere, "Montant insuffisant", (String valeur) -> {
			BigDecimal montantEncher = modellProduitEnVente.montantEnchereProperty().get() ;
			return montantEncher.compareTo( draft.getMeilleureOffre() ) <= 0;
		});
		
		// Bouton Valider
		btnEncherir.disableProperty().bind( validator.invalidProperty() );
	
	}
	
	
	@Override
	public void refresh() {
		txfMontantEchere.setDisable(true);
		var draft = modellProduitEnVente.getDraft();
		if(  draft.getDebutEncheres() != null
				&& draft.getFinEncheres() != null
				&& draft.getDebutEncheres().compareTo( modellProduitEnVente.getNow() ) <= 0
				&& draft.getFinEncheres().compareTo( modellProduitEnVente.getNow() ) >= 0
				)  {
			txfMontantEchere.setDisable(false);
			txfMontantEchere.requestFocus();
		}
	}
	
	
	// Actions
	
	@FXML
	private void doEncherir() {
		modellProduitEnVente.saveEnchere();
		managerGui.showView( ViewProduitEnVenteListe.class );
	}
	
	@FXML
	private void doRetour() {
		managerGui.showView( ViewProduitEnVenteListe.class );
	}
    
}
