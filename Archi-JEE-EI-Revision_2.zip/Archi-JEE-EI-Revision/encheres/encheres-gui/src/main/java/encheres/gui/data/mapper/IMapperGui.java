package encheres.gui.data.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import encheres.commun.dto.DtoEnchere;
import encheres.commun.dto.DtoProduit;
import encheres.commun.dto.DtoUtilisateur;
import encheres.gui.data.Enchere;
import encheres.gui.data.Produit;
import encheres.gui.data.Utilisateur;


@Mapper( componentModel = "spring" )
public interface IMapperGui {

	
	// Utilisateur

	Utilisateur map(DtoUtilisateur source);

	DtoUtilisateur map(Utilisateur source);

	Utilisateur update(@MappingTarget Utilisateur target, Utilisateur source);

	
	// Produit

	Produit map(DtoProduit source);

	DtoProduit map(Produit source);

	@Mapping( target="utilisateur", expression="java( source.getUtilisateur() )" )
	Produit update(@MappingTarget Produit target, Produit source);

	
	// Enchere

	Enchere map(DtoEnchere source);

	DtoEnchere map(Enchere source);

	@Mapping( target="produit", expression="java( source.getProduit() )" )
	@Mapping( target="utilisateur", expression="java( source.getUtilisateur() )" )
	Enchere update(@MappingTarget Enchere target, Enchere source);

}
