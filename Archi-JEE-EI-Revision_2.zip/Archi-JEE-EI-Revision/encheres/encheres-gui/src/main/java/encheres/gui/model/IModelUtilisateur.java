package encheres.gui.model;

import encheres.gui.data.Utilisateur;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableList;
import jfox.javafx.view.Mode;


public interface IModelUtilisateur {

	ObservableList<Utilisateur> getList();

	BooleanProperty flagRefreshingListProperty();

	Utilisateur getDraft();

	ObjectProperty<Utilisateur> currentProperty();

	Utilisateur getCurrent();

	void setCurrent(Utilisateur item);

	Mode getMode();

	void refreshList();

	void initDraft(Mode mode);

	void saveDraft();

	void deleteCurrent();

}