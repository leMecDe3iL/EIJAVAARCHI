package encheres.gui.view.utilisateur;

import javax.inject.Inject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import encheres.gui.model.IModelUtilisateur;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import jfox.javafx.util.converter.ConverterBigDecimal;
import jfox.javafx.util.converter.ConverterInteger;
import jfox.javafx.view.ControllerAbstract;
import jfox.javafx.view.IManagerGui;


@Component
@Scope( "prototype")
public class ViewUtilisateurForm extends ControllerAbstract  {
	
	
	// Composants de la vue
	
	@FXML
	private Label				labId;
	@FXML
	private TextField			txfNom;
	@FXML	
	private TextField			txfPrenom;
	@FXML
	private TextField			txfEmail;
	@FXML
	private TextField			txfPseudo;
	@FXML
	private TextField			txfMotDePasse;
	@FXML
	private CheckBox			ckbGextionnaire;
	@FXML
	private TextField			txfCredit;
	@FXML
	private Button				btnValider;

	
	// Autres champs
	@Inject
	private IManagerGui			managerGui;
	@Inject
	private IModelUtilisateur	modelUtilisateur;
    
	
	// Initialisation du controller
	
	public void initialize() {

		var draft = modelUtilisateur.getDraft();
		
		// Identifiant
		bind( labId, draft.idProperty(), new ConverterInteger() );
		
		// Nom
		bindBidirectional( txfNom, draft.nomProperty() );
		validator.addRuleNotBlank( txfNom ); 
		validator.addRuleMaxLength( txfNom, 25 ); 
		
		// Prénom
		bindBidirectional( txfPrenom, draft.prenomProperty() );
		validator.addRuleNotBlank( txfPrenom ); 
		validator.addRuleMaxLength( txfPrenom, 25 ); 
		
		// E-mail
		bindBidirectional( txfEmail, draft.emailProperty() );
		validator.addRuleNotBlank( txfEmail ); 
		validator.addRuleMaxLength( txfEmail, 50 );
		validator.addRuleEmail( txfEmail );
		
		// Pseudo
		bindBidirectional( txfPseudo, draft.pseudoProperty() );
		validator.addRuleNotBlank( txfPseudo ); 
		validator.addRuleMaxLength( txfPseudo, 25 ); 
		
		// Mot de passe
		bindBidirectional( txfMotDePasse, draft.motDePasseProperty() );
		validator.addRuleNotBlank( txfMotDePasse ); 
		validator.addRuleMaxLength( txfMotDePasse, 25 ); 
		
		// Flag gestionnaire
		bindBidirectional( ckbGextionnaire, draft.flagGestionnaireProperty() );
		
		// Crédit
		bindBidirectional( txfCredit, draft.creditProperty(), new ConverterBigDecimal( "#,##0.00" ) );
		validator.addRuleNotBlank( txfCredit ); 
		
		// Bouton Valider
		btnValider.disableProperty().bind( validator.invalidProperty() );
	
	}
	
	
	@Override
	public void refresh() {
		txfNom.requestFocus();
	}
	
	
	// Actions
	
	@FXML
	private void doValider() {
		modelUtilisateur.saveDraft();
		managerGui.showView( ViewUtilisateurListe.class );
	}
	
	@FXML
	private void doAnnuler() {
		managerGui.showView( ViewUtilisateurListe.class );
	}
    
}
