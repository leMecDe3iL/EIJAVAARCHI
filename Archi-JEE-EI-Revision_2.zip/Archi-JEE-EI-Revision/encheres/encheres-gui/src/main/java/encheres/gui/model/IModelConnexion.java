package encheres.gui.model;

import encheres.gui.data.Utilisateur;
import javafx.beans.property.ObjectProperty;


public interface IModelConnexion {

	Utilisateur getDraft();

	ObjectProperty<Utilisateur> utilisateurActifProperty();

	Utilisateur getUtilisateurActif();

	void ouvrirSessionUtilisateur();

	void fermerSessionUtilisateur();

}