package encheres.gui.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import encheres.gui.data.Produit;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableList;
import jfox.javafx.view.Mode;


public interface IModelProduitEnVente {

	ObservableList<Produit> getList();

	BooleanProperty flagRefreshingListProperty();

	Produit getDraft();

	ObjectProperty<Produit> currentProperty();

	Produit getCurrent();

	void setCurrent(Produit item);

	Mode getMode();
	
	LocalDateTime getNow();

	void refreshList();

	void initDraft(Mode mode);

	void saveEnchere();

	ObjectProperty<BigDecimal> montantEnchereProperty();

}