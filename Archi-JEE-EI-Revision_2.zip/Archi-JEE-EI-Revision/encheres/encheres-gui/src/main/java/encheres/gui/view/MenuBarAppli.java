package encheres.gui.view;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import encheres.gui.model.IModelConnexion;
import encheres.gui.view.encheres.ViewProduitEnVenteListe;
import encheres.gui.view.systeme.ViewConnexion;
import encheres.gui.view.utilisateur.ViewUtilisateurListe;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.control.Menu;
import jfox.javafx.control.MenuBarAbstract;
import jfox.javafx.view.IManagerGui;


@Component 
@Scope( "prototype")
public class MenuBarAppli extends MenuBarAbstract {

	
	// Champs 
	
	private final BooleanProperty flagConnexion		= new SimpleBooleanProperty();
	private final BooleanProperty flagRoleGestion	= new SimpleBooleanProperty();
	
	@Inject
	private IManagerGui 	managerGui;
	@Inject
	private IModelConnexion	modelConnexion;	
	
	
	// Initialisation
	
	@PostConstruct
	public void init() {
		
		// Variables de travail
		Menu menu;
		
		
		// Manu Système
		
		menu = addMenu( "Système", null, null );

		addMenuItem( "Se déconnecter", menu, flagConnexion,
				e -> managerGui.showView( ViewConnexion.class ) );

		addMenuItem( "Quitter", menu, null, e -> managerGui.exit() );

		
		// Manu Données
		
		menu = addMenu( "Donnees", null,  flagConnexion );
		
//		addMenuItem( "Personnes", menu, null,
//				e -> managerGui.showView( ViewPersonneListe.class ) );
//		
//		addMenuItem( "Catégories", menu, flagRoleAdmin, 
//				e -> managerGui.showView( ViewCategorieCombo.class ) );
		
		addMenuItem( "Utilisateurs", menu, flagRoleGestion, 
				e -> managerGui.showView( ViewUtilisateurListe.class ) );

		
		// Manu Encères
		
		menu = addMenu( "Enchère", null,  flagConnexion );
		
		addMenuItem( "Produits", menu, flagConnexion, 
				e -> managerGui.showView( ViewProduitEnVenteListe.class ) );

		
		// Gestion des droits d'accès
		
		final var utilisateurActif = modelConnexion.utilisateurActifProperty();
		flagConnexion.bind( utilisateurActif.isNotNull() );
		flagRoleGestion.bind( Bindings.createBooleanBinding( () -> flagConnexion.get() && utilisateurActif.get().isFlagGestionnaire(), utilisateurActif ) );
	}
}
