package encheres.gui.data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class Produit {

	
	// Champs
	
	private final ObjectProperty<Integer>		id 			= new SimpleObjectProperty<>();
	private final ObjectProperty<Utilisateur>	utilisateur	= new SimpleObjectProperty<>();;
	private final StringProperty				nom			= new SimpleStringProperty();
	private final ObjectProperty<BigDecimal>	prixMinimal	= new SimpleObjectProperty<>();
	private final ObjectProperty<LocalDateTime>	debutEncheres	= new SimpleObjectProperty<>();
	private final ObjectProperty<LocalDateTime>	finEncheres	= new SimpleObjectProperty<>();
	private final BooleanProperty				flagCloture= new SimpleBooleanProperty();
	private final ObjectProperty<Integer>		nbEncheres	= new SimpleObjectProperty<>();
	private final ObjectProperty<BigDecimal>	meilleureOffre	= new SimpleObjectProperty<>();

	
	// Getters & Setters 

	public final ObjectProperty<Integer> idProperty() {
		return this.id;
	}
	public final Integer getId() {
		return this.idProperty().get();
	}
	public final void setId(final Integer id) {
		this.idProperty().set(id);
	}

	public final ObjectProperty<Utilisateur> utilisateurProperty() {
		return this.utilisateur;
	}
	public final Utilisateur getUtilisateur() {
		return this.utilisateurProperty().get();
	}
	public final void setUtilisateur(final Utilisateur utilisateur) {
		this.utilisateurProperty().set(utilisateur);
	}

	public final StringProperty nomProperty() {
		return this.nom;
	}
	public final String getNom() {
		return this.nomProperty().get();
	}
	public final void setNom(final String nom) {
		this.nomProperty().set(nom);
	}

	public final ObjectProperty<BigDecimal> prixMinimalProperty() {
		return this.prixMinimal;
	}
	public final BigDecimal getPrixMinimal() {
		return this.prixMinimalProperty().get();
	}
	public final void setPrixMinimal(final BigDecimal prixMinimal) {
		this.prixMinimalProperty().set(prixMinimal);
	}

	public final ObjectProperty<LocalDateTime> debutEncheresProperty() {
		return this.debutEncheres;
	}
	public final LocalDateTime getDebutEncheres() {
		return this.debutEncheresProperty().get();
	}
	public final void setDebutEncheres(final LocalDateTime debutEncheres) {
		this.debutEncheresProperty().set(debutEncheres);
	}

	public final ObjectProperty<LocalDateTime> finEncheresProperty() {
		return this.finEncheres;
	}
	public final LocalDateTime getFinEncheres() {
		return this.finEncheresProperty().get();
	}
	public final void setFinEncheres(final LocalDateTime finEncheres) {
		this.finEncheresProperty().set(finEncheres);
	}

	public final BooleanProperty flagClotureProperty() {
		return this.flagCloture;
	}
	public final boolean isFlagCloture() {
		return this.flagClotureProperty().get();
	}
	public final void setFlagCloture(final boolean flagCloture) {
		this.flagClotureProperty().set(flagCloture);
	}

	public final ObjectProperty<Integer> nbEncheresProperty() {
		return this.nbEncheres;
	}
	public final Integer getNbEncheres() {
		return this.nbEncheresProperty().get();
	}
	public final void setNbEncheres(final Integer nbEncheres) {
		this.nbEncheresProperty().set(nbEncheres);
	}

	public final ObjectProperty<BigDecimal> meilleureOffreProperty() {
		return this.meilleureOffre;
	}
	public final BigDecimal getMeilleureOffre() {
		return this.meilleureOffreProperty().get();
	}
	public final void setMeilleureOffre(final BigDecimal meilleureOffre) {
		this.meilleureOffreProperty().set(meilleureOffre);
	}

	
	//hashCode() & equals()
	
	@Override
	public int hashCode() {
		return Objects.hash(id.get());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Produit))
			return false;
		Produit other = (Produit) obj;
		return id.get() == other.id.get();
	}
	
	
}
