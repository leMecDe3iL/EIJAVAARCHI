package encheres.gui.data;

import java.math.BigDecimal;
import java.util.Objects;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class Utilisateur {
	
	
	// Champs
	
	private final ObjectProperty<Integer>		id 			= new SimpleObjectProperty<>();
	private final StringProperty				nom			= new SimpleStringProperty();
	private final StringProperty				prenom		= new SimpleStringProperty();
	private final StringProperty				email		= new SimpleStringProperty();
	private final StringProperty				pseudo		= new SimpleStringProperty();
	private final StringProperty				motDePasse	= new SimpleStringProperty();
	private final BooleanProperty			 	flagGestionnaire = new SimpleBooleanProperty();
	private final ObjectProperty<BigDecimal>	credit		= new SimpleObjectProperty<>();
	
	
	// Getters & Setters
	
	public final ObjectProperty<Integer> idProperty() {
		return this.id;
	}
	
	public final Integer getId() {
		return this.idProperty().get();
	}
	
	public final void setId(final Integer id) {
		this.idProperty().set(id);
	}
	
	public final StringProperty nomProperty() {
		return this.nom;
	}
	
	public final String getNom() {
		return this.nomProperty().get();
	}
	
	public final void setNom(final String nom) {
		this.nomProperty().set(nom);
	}
	
	public final StringProperty prenomProperty() {
		return this.prenom;
	}
	
	public final String getPrenom() {
		return this.prenomProperty().get();
	}
	
	public final void setPrenom(final String prenom) {
		this.prenomProperty().set(prenom);
	}
	
	public final StringProperty emailProperty() {
		return this.email;
	}
	
	public final String getEmail() {
		return this.emailProperty().get();
	}
	
	public final void setEmail(final String email) {
		this.emailProperty().set(email);
	}
	
	public final StringProperty pseudoProperty() {
		return this.pseudo;
	}
	
	public final String getPseudo() {
		return this.pseudoProperty().get();
	}
	
	public final void setPseudo(final String pseudo) {
		this.pseudoProperty().set(pseudo);
	}
	
	public final StringProperty motDePasseProperty() {
		return this.motDePasse;
	}
	
	public final String getMotDePasse() {
		return this.motDePasseProperty().get();
	}
	
	public final void setMotDePasse(final String motDePasse) {
		this.motDePasseProperty().set(motDePasse);
	}
	
	public final BooleanProperty flagGestionnaireProperty() {
		return this.flagGestionnaire;
	}
	
	public final boolean isFlagGestionnaire() {
		return this.flagGestionnaireProperty().get();
	}
	
	public final void setFlagGestionnaire(final boolean flagGestionnaire) {
		this.flagGestionnaireProperty().set(flagGestionnaire);
	}
	
	public final ObjectProperty<BigDecimal> creditProperty() {
		return this.credit;
	}
	
	public final BigDecimal getCredit() {
		return this.creditProperty().get();
	}
	
	public final void setCredit(final BigDecimal credit) {
		this.creditProperty().set(credit);
	}


	
	//hashCode() & equals()
	
	@Override
	public int hashCode() {
		return Objects.hash(id.get());
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Utilisateur))
			return false;
		Utilisateur other = (Utilisateur) obj;
		return id.get() == other.id.get();
	}
	
}
