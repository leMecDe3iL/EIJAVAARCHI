package encheres.gui.model;

import javafx.beans.property.StringProperty;

public interface IModelInfo {

	StringProperty titreProperty();

	StringProperty messageProperty();

}