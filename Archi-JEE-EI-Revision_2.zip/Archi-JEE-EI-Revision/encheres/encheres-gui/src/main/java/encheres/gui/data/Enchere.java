package encheres.gui.data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;


public class Enchere {

	
	// Champs
	
	private final ObjectProperty<Integer>		id 			= new SimpleObjectProperty<>();
	private final ObjectProperty<Produit>		produit		= new SimpleObjectProperty<>();
	private final ObjectProperty<Utilisateur>	utilisateur	= new SimpleObjectProperty<>();
	private final ObjectProperty<BigDecimal>	montant		= new SimpleObjectProperty<>();
	private final ObjectProperty<LocalDateTime>	dateHeure	= new SimpleObjectProperty<>();
	
	
	// Getters & Setters

	public final ObjectProperty<Integer> idProperty() {
		return this.id;
	}
	
	public final Integer getId() {
		return this.idProperty().get();
	}
	
	public final void setId(final Integer id) {
		this.idProperty().set(id);
	}
	
	public final ObjectProperty<Produit> produitProperty() {
		return this.produit;
	}
	
	public final Produit getProduit() {
		return this.produitProperty().get();
	}
	
	public final void setProduit(final Produit produit) {
		this.produitProperty().set(produit);
	}
	
	public final ObjectProperty<Utilisateur> utilisateurProperty() {
		return this.utilisateur;
	}
	
	public final Utilisateur getUtilisateur() {
		return this.utilisateurProperty().get();
	}
	
	public final void setUtilisateur(final Utilisateur utilisateur) {
		this.utilisateurProperty().set(utilisateur);
	}
	
	public final ObjectProperty<BigDecimal> montantProperty() {
		return this.montant;
	}
	
	public final BigDecimal getMontant() {
		return this.montantProperty().get();
	}
	
	public final void setMontant(final BigDecimal montant) {
		this.montantProperty().set(montant);
	}
	
	public final ObjectProperty<LocalDateTime> dateHeureProperty() {
		return this.dateHeure;
	}
	
	public final LocalDateTime getDateHeure() {
		return this.dateHeureProperty().get();
	}
	
	public final void setDateHeure(final LocalDateTime dateHeure) {
		this.dateHeureProperty().set(dateHeure);
	}

	
	//hashCode() & equals()
	
	@Override
	public int hashCode() {
		return Objects.hash(id.get());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Enchere))
			return false;
		Enchere other = (Enchere) obj;
		return id.get() == other.id.get();
	}
	
}
