package encheres.gui.model.standard;


import javax.inject.Inject;

import org.springframework.stereotype.Component;

import encheres.commun.dto.DtoUtilisateur;
import encheres.commun.service.IServiceUtilisateur;
import encheres.gui.data.Utilisateur;
import encheres.gui.data.mapper.IMapperGui;
import encheres.gui.model.IModelUtilisateur;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jfox.javafx.util.UtilFX;
import jfox.javafx.view.Mode;


@Component
public class ModelUtilisateur implements IModelUtilisateur {
	
	
	// Données observables 
	
	private final ObservableList<Utilisateur> list = FXCollections.observableArrayList(); 
	
	private final BooleanProperty 		flagRefreshingList = new SimpleBooleanProperty();
	
	private final Utilisateur				draft 		= new Utilisateur();
	
	private final ObjectProperty<Utilisateur> current 	= new SimpleObjectProperty<>();
	
	
	// Autres champs
	
	private Mode			mode;

    @Inject
	private IMapperGui		mapper;
    @Inject
	private IServiceUtilisateur	serviceUtilisateur;
	
	
	// Getters & Setters
	
    @Override
	public ObservableList<Utilisateur> getList() {
		return list;
	}

    @Override
	public BooleanProperty flagRefreshingListProperty() {
		return flagRefreshingList;
	}
	
    @Override
	public Utilisateur getDraft() {
		return draft;
	}

    @Override
	public ObjectProperty<Utilisateur> currentProperty() {
		return current;
	}

    @Override
	public Utilisateur getCurrent() {
		return current.getValue();
	}

    @Override
	public void setCurrent(Utilisateur item) {
		current.setValue(item);
	}
	
    @Override
	public Mode getMode() {
		return mode;
	}
	
	
	// Actions
	
    @Override
	public void refreshList() {
		// flagRefreshingList vaut true pendant la durée  
		// du traitement de mise à jour de la liste
		flagRefreshingList.set(true);
		list.clear();
		for( DtoUtilisateur dto : serviceUtilisateur.listerTout() ) {
			var item = mapper.map( dto );
			list.add( item );
		}
		flagRefreshingList.set(false);
 	}

	
    @Override
	public void initDraft(Mode mode) {
		this.mode = mode;
		if( mode == Mode.NEW ) {
			mapper.update( draft, new Utilisateur() );
		} else {
			setCurrent( mapper.map( serviceUtilisateur.retrouver( getCurrent().getId() ) ) );
			mapper.update( draft, getCurrent() );
		}
	}
	
	
    @Override
	public void saveDraft() {
		
		try {
			
			// Enregistre les données dans la base
			
			DtoUtilisateur dto = mapper.map( draft );
			
			if ( mode == Mode.NEW ) {
				// Insertion
				draft.setId( serviceUtilisateur.inserer( dto ) );
				// Actualise le courant
				setCurrent( mapper.update( new Utilisateur(), draft ) );
			} else {
				// modficiation
				serviceUtilisateur.modifier( dto );
				// Actualise le courant
				mapper.update( getCurrent(), draft );
			}
		} catch ( Exception e) {
			throw UtilFX.runtimeException( e );
		}
	}
	
	
    @Override
	public void deleteCurrent() {
		
		try {
			// Effectue la suppression
			serviceUtilisateur.supprimer( getCurrent().getId() );
			// Détermine le nouveau courant
			setCurrent( UtilFX.findNext( list, getCurrent() ) );
		} catch ( Exception e) {
			throw UtilFX.runtimeException( e );
		}
	}

}
