package encheres.gui.view.utilisateur;

import javax.inject.Inject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import encheres.gui.data.Utilisateur;
import encheres.gui.model.IModelUtilisateur;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import jfox.javafx.util.UtilFX;
import jfox.javafx.view.ControllerAbstract;
import jfox.javafx.view.IManagerGui;
import jfox.javafx.view.Mode;


@Component
@Scope( "prototype")
public class ViewUtilisateurListe extends ControllerAbstract  {
	
	
	// Composants de la vue
	
	@FXML
	private ListView<Utilisateur>	lsvUtilisateurs;
	@FXML
	private Button				btnModifier;
	@FXML
	private Button				btnSupprimer;
	
	
	// Autres champs
	
	@Inject
	private IManagerGui			managerGui;
	@Inject
	private IModelUtilisateur	modelUtilisateur;
	
	
	// Initialisation du controller

	@FXML
	private void initialize() {
		
		// ListView
		lsvUtilisateurs.setItems( modelUtilisateur.getList() );
		UtilFX.setCellFactory( lsvUtilisateurs, item -> item.getNom() + " " + item.getPrenom()  );
		bindBidirectional( lsvUtilisateurs, modelUtilisateur.currentProperty(), modelUtilisateur.flagRefreshingListProperty() );
		
		// Configuraiton des boutons
		lsvUtilisateurs.getSelectionModel().selectedItemProperty().addListener(obs -> {
			configurerBoutons();
		});
    	configurerBoutons();
	}

	
	@Override
	public void refresh() {
		modelUtilisateur.refreshList();
		lsvUtilisateurs.requestFocus();
	}
	
	
	// Actions
	
	@FXML
	private void doAjouter() {
		modelUtilisateur.initDraft( Mode.NEW );;
		managerGui.showView( ViewUtilisateurForm.class );
	}
	
	@FXML
	private void doModifier() {
		modelUtilisateur.initDraft( Mode.EDIT );;
		managerGui.showView( ViewUtilisateurForm.class );
	}
	
	@FXML
	private void doSupprimer() {
		if ( managerGui.showDialogConfirm("Etes-vous sûr de voulir supprimer cet utilisateur ?" ) ) {
			modelUtilisateur.deleteCurrent();
			refresh();
		}
	}
	
	
	// Gestion des évènements

	// Clic sur la liste
	@FXML
	private void gererClicSurListe( MouseEvent event ) {
		if (event.getButton().equals(MouseButton.PRIMARY)) {
			if (event.getClickCount() == 2) {
				if ( lsvUtilisateurs.getSelectionModel().getSelectedIndex() == -1 ) {
					managerGui.showDialogError( "Aucun élément n'est sélectionné dans la liste.");
				} else {
					doModifier();
				}
			}
		}
	}

	
	// Méthodes auxiliaires
	
	private void configurerBoutons() {
		var flagDisable = lsvUtilisateurs.getSelectionModel().getSelectedItem() == null;
		btnModifier.setDisable(flagDisable);
		btnSupprimer.setDisable(flagDisable);
	}
	
}
