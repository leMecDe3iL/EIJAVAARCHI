package encheres;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Lazy;

import encheres.commun.service.IServiceConnexion;
import encheres.commun.service.IServiceEnchere;
import encheres.commun.service.IServiceProduit;
import encheres.commun.service.IServiceUtilisateur;
import encheres.gui.model.IModelConnexion;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import jfox.javafx.util.UtilFX;
import jfox.javafx.view.ManagerGuiAbstract;


@Lazy
@ComponentScan(
		basePackages = {
				"encheres.gui.view",
				"encheres.gui.data.mapper",
				"encheres.gui.model.standard",
		},
		lazyInit = true	)
public class Appli3Ejb extends Application {

	
	// Titre de la fenêtre
	private static final String TITRE = "Enchères EJB";

	
	// Champs
	
	private AnnotationConfigApplicationContext	context;
	
	
	// Actions
	
	@Override
	public final void start(Stage stage) {
		
		try {
			
			// Context
			context = new AnnotationConfigApplicationContext();
			context.register( Appli3Ejb.class );
			context.refresh();

			// ManagerGui
	    	var managerGui = context.getBean( ManagerGuiAbstract.class );
	    	managerGui.setFactoryController( context::getBean );
			managerGui.setStage( stage );
			managerGui.configureStage();
			
			// Affiche le stage
			var modelConnexion = context.getBean( IModelConnexion.class );
			stage.titleProperty().bind(Bindings.createStringBinding( () -> {
				var utilisateurActif = modelConnexion.getUtilisateurActif();
				if ( utilisateurActif != null ) {
					return TITRE + " - " + utilisateurActif.getNom() + " " +utilisateurActif.getPrenom();
				} else {
					return TITRE;
				}
			},modelConnexion.utilisateurActifProperty())  );
			stage.show();
			
		} catch(Exception e) {
			UtilFX.unwrapException(e).printStackTrace();
			e.printStackTrace();
	        Alert alert = new Alert(AlertType.ERROR);
	        alert.setHeaderText( "Impossible de démarrer l'application." );
	        alert.showAndWait();
	        Platform.exit();
		}

	}
	
	@Override
	public final void stop() throws Exception {

		if (context != null ) {
			context.close();
		}
	}
	

	
	// Classe interne Main
	
	public static class Main {
		public static void main(String[] args) {
			Application.launch( Appli3Ejb.class, args);
		}
	}

	
	
	// Définitions des beans pour Spring
	
	@Bean 
	public InitialContext initialContext() throws NamingException {
		return new InitialContext();
	}
	
	@Bean
	public IServiceConnexion serviceConnexion( InitialContext ic  ) throws NamingException {
		return (IServiceConnexion) ic.lookup( "encheres/ejb/ServiceConnexion!encheres.commun.service.IServiceConnexion" );
	}
	
	@Bean
	public IServiceEnchere serviceEnchere( InitialContext ic  ) throws NamingException {
		return (IServiceEnchere) ic.lookup( "encheres/ejb/ServiceEnchere!encheres.commun.service.IServiceEnchere" );
	}
	
	@Bean
	public IServiceProduit serviceProduit( InitialContext ic  ) throws NamingException {
		return (IServiceProduit) ic.lookup( "encheres/ejb/ServiceProduit!encheres.commun.service.IServiceProduit" );
	}
	
	@Bean
	public IServiceUtilisateur serviceUtilisateur( InitialContext ic  ) throws NamingException {
		return (IServiceUtilisateur) ic.lookup( "encheres/ejb/ServiceUtilisateur!encheres.commun.service.IServiceUtilisateur" );
	}
	
}
