package encheres;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.PrintStream;
import java.time.LocalDateTime;

import javax.naming.InitialContext;

import encheres.commun.service.IServiceProduit;
import encheres.commun.service.IServiceUtilisateur;

public class TestEjb {

	public static void main(String[] args) throws Exception {

		var ic = new InitialContext();

		var serviceUtilisateur = (IServiceUtilisateur) ic
				.lookup("java:global/enchere-app/enchere-ejb/ServiceUtilisateur");

		var serviceProduit = (IServiceProduit) ic.lookup("java:global/enchere-app/enchere-ejb/ServiceProduit");
		PrintStream out = new PrintStream(System.out, true, UTF_8);

		for (var item : serviceUtilisateur.listerTout()) {
			out.println(item.getNom());
		}

		out.println();
		var dateHeure = LocalDateTime.parse("2023-04-10T12:00:00");
		for (var item : serviceProduit.listerAVendre(dateHeure)) {
			out.println(item.getNom());
		}

		ic.close();
	}
}
