package encheres.ejb.data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;


public class Enchere {

	
	// Champs
	
	private int				id;
	
	private Produit			produit;
	
	private Utilisateur		utilisateur;
	
	private BigDecimal		montant;
	
	private LocalDateTime	dateHeure;
	
	
	// Getters & Setters

	public int getId() {
		return id;
	}

	public void setId(int idEnchere) {
		this.id = idEnchere;
	}

	public Produit getProduit() {
		return produit;
	}

	public void setProduit(Produit produit) {
		this.produit = produit;
	}

	public Utilisateur getUtilisateur() {
		return utilisateur;
	}

	public void setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}

	public BigDecimal getMontant() {
		return montant;
	}

	public void setMontant(BigDecimal montant) {
		this.montant = montant;
	}

	public LocalDateTime getDateHeure() {
		return dateHeure;
	}

	public void setDateHeure(LocalDateTime dateHeure) {
		this.dateHeure = dateHeure;
	}

	
	//hashCode() & equals()
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Enchere))
			return false;
		Enchere other = (Enchere) obj;
		return id == other.id;
	}

	
	// Constructeurs
	
	public Enchere() {
	}

	public Enchere(int id, Produit produit, Utilisateur utilisateur, String montant, String dateHeure) {
		this.id = id;
		this.produit = produit;
		this.utilisateur = utilisateur;
		this.montant = montant == null ? null : new BigDecimal(montant);
		this.dateHeure = dateHeure == null ? null : LocalDateTime.parse(dateHeure);
	}
	
	
}
