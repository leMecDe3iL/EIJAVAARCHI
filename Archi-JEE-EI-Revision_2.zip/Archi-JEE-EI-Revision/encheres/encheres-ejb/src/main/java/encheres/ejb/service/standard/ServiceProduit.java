package encheres.ejb.service.standard;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import encheres.commun.dto.DtoProduit;
import encheres.commun.exception.ExceptionValidation;
import encheres.commun.service.IServiceProduit;
import encheres.ejb.dao.IDaoEnchere;
import encheres.ejb.dao.IDaoProduit;
import encheres.ejb.data.Enchere;
import encheres.ejb.data.Produit;
import encheres.ejb.data.mapper.IMapper;

@Stateless
@Remote
public class ServiceProduit implements IServiceProduit {

	
	// Champs 
	@Inject
	private IMapper		mapper;
	@Inject
	private IDaoProduit	daoProduit;
	@Inject
	private IDaoEnchere	daoEnchere;
	

	// Actions 

	@Override
	public int inserer( DtoProduit dtoProduit ) throws ExceptionValidation {
		verifierValiditeDonnees( dtoProduit );
		int id = daoProduit.inserer( mapper.map( dtoProduit ) );
		return id;
	}

	@Override
	public void modifier( DtoProduit dtoProduit ) throws ExceptionValidation {
		verifierValiditeDonnees( dtoProduit );
		daoProduit.modifier( mapper.map( dtoProduit ) );
	}

	@Override
	public void supprimer( int idProduit ) throws ExceptionValidation {
        if ( daoEnchere.compterPourProduit(idProduit) != 0 ) {
            throw new ExceptionValidation( "Des produits sont rattachés à cet produit" );
        }
		daoProduit.supprimer(idProduit);
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public DtoProduit retrouver( int idProduit ) {
		return map( daoProduit.retrouver(idProduit) );
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<DtoProduit> listerAVendre( LocalDateTime dateHeure) {
		List<DtoProduit> liste = new ArrayList<>();
		for( Produit item : daoProduit.listerAVendre( dateHeure ) ) {
			liste.add( map( item ) );
		}
		return liste;
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<DtoProduit> listerAVendre( int idUtilisateur) {
		List<DtoProduit> liste = new ArrayList<>();
		for( Produit item : daoProduit.listerPourUtilisateur( idUtilisateur ) ) {
			liste.add( mapper.map( item ) );
		}
		return liste;
	}

	
	
	// Méthodes auxiliaires
	
	private DtoProduit map( Produit produit ) {

		DtoProduit dto = mapper.map( produit );
		
		Enchere enchere = daoEnchere.meilleurePourProduit( produit.getId() );
		if ( enchere == null ) {
			dto.setMeilleureOffre( dto.getPrixMinimal()  );
			dto.setNbEncheres(0);
		} else {
			dto.setMeilleureOffre( enchere.getMontant()  );
			dto.setNbEncheres( daoEnchere.compterPourProduit(produit.getId()) );
		}
		return dto;
	}
	
	private void verifierValiditeDonnees( DtoProduit dtoProduit ) throws ExceptionValidation {
		
		StringBuilder message = new StringBuilder();
		
		if ( dtoProduit.getUtilisateur() == null ) {
			message.append( "\nL'utilisateur est obligatoire." );
		}
		
		if ( dtoProduit.getNom() == null || dtoProduit.getNom().isEmpty() ) {
			message.append( "\nLe nom est obligatoire." );
		} else 	if ( dtoProduit.getNom().length() < 3 ) {
			message.append( "\nLe nom est trop court." );
		} else 	if ( dtoProduit.getNom().length() > 25 ) {
			message.append( "\nLe nom est trop long." );
		}
		
		if ( dtoProduit.getPrixMinimal() == null  ) {
			message.append( "\nLe prix minimal est obligatoire." );
		} else 	if ( dtoProduit.getPrixMinimal().doubleValue() < 0 ) {
			message.append( "\nLe prix minimal doit être supérieur ou égal à zéro." );
		}
		
		if ( message.length() > 0 ) {
			throw new ExceptionValidation( message.toString().substring(1) );
		}
	}

}
