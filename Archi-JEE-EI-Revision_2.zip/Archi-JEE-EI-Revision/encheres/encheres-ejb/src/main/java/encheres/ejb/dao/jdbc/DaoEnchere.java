package encheres.ejb.dao.jdbc;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.sql.DataSource;

import encheres.ejb.dao.IDaoEnchere;
import encheres.ejb.dao.IDaoProduit;
import encheres.ejb.dao.IDaoUtilisateur;
import encheres.ejb.dao.UtilJdbc;
import encheres.ejb.data.Enchere;

@Stateless
@Local
public class DaoEnchere implements IDaoEnchere {

	// Champs
	@Resource(lookup = "java:/ds/encheres")
	private DataSource dataSource;
	@Inject
	private IDaoProduit daoProduit;
	@Inject
	private IDaoUtilisateur daoUtilisateur;

	// Actions

	@Override
	public int inserer(Enchere item) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			// Insère le enchere
			sql = "INSERT INTO enchere ( idproduit, idutilisateur, montant, dateheure ) VALUES ( ?, ?, ?, ? )";
			stmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setObject(1, item.getProduit() == null ? null : item.getProduit().getId());
			stmt.setObject(2, item.getUtilisateur() == null ? null : item.getUtilisateur().getId());
			stmt.setObject(3, item.getMontant());
			stmt.setObject(4, item.getDateHeure());
			stmt.executeUpdate();

			// Récupère l'identifiant généré par le SGBD
			rs = stmt.getGeneratedKeys();
			rs.next();
			item.setId(rs.getObject(1, Integer.class));

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}

		// Retourne l'identifiant
		return item.getId();
	}

	@Override
	public void modifier(Enchere item) {

		Connection cn = null;
		PreparedStatement stmt = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			// Modifie le enchere
			sql = "UPDATE enchere SET idproduit = ?, idutilisateur = ?, montant = ?, dateheure = ? WHERE idenchere =  ?";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, item.getProduit() == null ? null : item.getProduit().getId());
			stmt.setObject(2, item.getUtilisateur() == null ? null : item.getUtilisateur().getId());
			stmt.setObject(3, item.getMontant());
			stmt.setObject(4, item.getDateHeure());
			stmt.setObject(5, item.getId());
			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(stmt, cn);
		}
	}

	@Override
	public void supprimer(int idEnchere) {

		Connection cn = null;
		PreparedStatement stmt = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			// Supprime le enchere
			sql = "DELETE FROM enchere WHERE idenchere = ? ";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, idEnchere);
			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(stmt, cn);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public Enchere retrouver(int idEnchere) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			sql = "SELECT * FROM enchere WHERE idenchere = ?";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, idEnchere);
			rs = stmt.executeQuery();

			if (rs.next()) {
				return construireEnchere(rs, true);
			} else {
				return null;
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public int compterPourProduit(int idProduit) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			sql = "SELECT COUNT(*) FROM enchere WHERE idproduit = ?";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, idProduit);
			rs = stmt.executeQuery();

			rs.next();
			return rs.getInt(1);

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public Enchere meilleurePourProduit(int idProduit) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			sql = "SELECT * FROM enchere WHERE idproduit = ? ORDER BY dateheure DESC LIMIT 1";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, idProduit);
			rs = stmt.executeQuery();

			if (rs.next()) {
				return construireEnchere(rs, true);
			} else {
				return null;
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}
	}

	// Méthodes auxiliaires

	protected Enchere construireEnchere(ResultSet rs, boolean flagComplet) throws SQLException {
		var item = new Enchere();
		item.setId(rs.getObject("idenchere", Integer.class));
		item.setMontant(rs.getObject("montant", BigDecimal.class));
		item.setDateHeure(rs.getObject("dateheure", LocalDateTime.class));

		if (flagComplet) {
			item.setProduit(daoProduit.retrouver(rs.getObject("idproduit", Integer.class)));
			item.setUtilisateur(daoUtilisateur.retrouver(rs.getObject("idutilisateur", Integer.class)));
		}

		return item;
	}

}
