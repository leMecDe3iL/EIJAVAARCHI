package encheres.ejb.dao;

import encheres.ejb.data.Enchere;

public interface IDaoEnchere {

	int inserer(Enchere enchere);

	void modifier(Enchere enchere);

	void supprimer(int idEnchere);

	Enchere retrouver(int idEnchere);

	int compterPourProduit(int idProduit);

	Enchere meilleurePourProduit(int idProduit);

}