package encheres.ejb.service.standard;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import encheres.commun.dto.DtoUtilisateur;
import encheres.commun.exception.ExceptionValidation;
import encheres.commun.service.IServiceUtilisateur;
import encheres.ejb.dao.IDaoUtilisateur;
import encheres.ejb.data.Utilisateur;
import encheres.ejb.data.mapper.IMapper;

@Stateless
@Remote
public class ServiceUtilisateur implements IServiceUtilisateur {

	// Champs

	@Inject
	private IMapper mapper;
	@Inject
	private IDaoUtilisateur daoUtilisateur;

	// Actions

	@Override
	public int inserer(DtoUtilisateur dtoUtilisateur) throws ExceptionValidation {
		verifierValiditeDonnees(dtoUtilisateur);
		int id = daoUtilisateur.inserer(mapper.map(dtoUtilisateur));
		return id;
	}

	@Override
	public void modifier(DtoUtilisateur dtoUtilisateur) throws ExceptionValidation {
		verifierValiditeDonnees(dtoUtilisateur);
		daoUtilisateur.modifier(mapper.map(dtoUtilisateur));
	}

	@Override @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void supprimer(int idUtilisateur) throws ExceptionValidation {
		daoUtilisateur.supprimer(idUtilisateur);
	}

	@Override
	public DtoUtilisateur retrouver(int idUtilisateur) {
		return mapper.map(daoUtilisateur.retrouver(idUtilisateur));
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<DtoUtilisateur> listerTout() {
		List<DtoUtilisateur> liste = new ArrayList<>();
		for (Utilisateur categorie : daoUtilisateur.listerTout()) {
			liste.add(mapper.map(categorie));
		}
		return liste;
	}

	// Méthodes auxiliaires

	private void verifierValiditeDonnees(DtoUtilisateur dtoUtilisateur) throws ExceptionValidation {

		StringBuilder message = new StringBuilder();

		if (dtoUtilisateur.getNom() == null || dtoUtilisateur.getNom().isEmpty()) {
			message.append("\nLe nom est obligatoire.");
		} else if (dtoUtilisateur.getNom().length() > 25) {
			message.append("\nLe nom est trop long.");
		}

		if (dtoUtilisateur.getPrenom() == null || dtoUtilisateur.getPrenom().isEmpty()) {
			message.append("\nLe prénom est obligatoire.");
		} else if (dtoUtilisateur.getPrenom().length() > 25) {
			message.append("\nLe prénom est trop long.");
		}

		if (dtoUtilisateur.getEmail() == null || dtoUtilisateur.getEmail().isEmpty()) {
			message.append("\nL'adresse e-mail est obligatoire.");
		} else if (dtoUtilisateur.getEmail().length() > 50) {
			message.append("\nL'adresse e-mail est trop longue.");
		} else if (!dtoUtilisateur.getEmail().matches(
				"(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\\.){3}(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9])|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])")) {
			message.append("\nAadresse e-mail incorrecte.");
		}

		if (dtoUtilisateur.getPseudo() == null || dtoUtilisateur.getPseudo().isEmpty()) {
			message.append("\nLe pseudo est obligatoire.");
		} else if (dtoUtilisateur.getPseudo().length() > 25) {
			message.append("\nLe pseudo est trop long.");
		}

		if (dtoUtilisateur.getMotDePasse() == null || dtoUtilisateur.getMotDePasse().isEmpty()) {
			message.append("\nLe met de passe est obligatoire.");
		} else if (dtoUtilisateur.getMotDePasse().length() > 25) {
			message.append("\nLe met de passe est trop long.");
		}

		if (message.length() > 0) {
			throw new ExceptionValidation(message.toString().substring(1));
		}
	}

}
