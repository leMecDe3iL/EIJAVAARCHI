package encheres.ejb.data.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import encheres.commun.dto.DtoEnchere;
import encheres.commun.dto.DtoProduit;
import encheres.commun.dto.DtoUtilisateur;
import encheres.ejb.data.Enchere;
import encheres.ejb.data.Produit;
import encheres.ejb.data.Utilisateur;

@Mapper( componentModel = "cdi" )
public interface IMapper {
	
	
	// Utilisateur
	
	@Mapping( target = "produits", ignore = true )
	Utilisateur map( DtoUtilisateur source );
	
	DtoUtilisateur map( Utilisateur source );
	
	
	// Produit
	
	Produit map( DtoProduit source );
	
	@Mapping( target="nbEncheres", ignore=true )
	@Mapping( target="meilleureOffre", ignore=true )
	DtoProduit map( Produit source );
	
	
	// Enchere
	
	Enchere map( DtoEnchere source );
	
	DtoEnchere map( Enchere source );

}
