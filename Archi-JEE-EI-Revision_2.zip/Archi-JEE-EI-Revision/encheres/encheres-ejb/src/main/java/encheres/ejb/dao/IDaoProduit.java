package encheres.ejb.dao;

import java.time.LocalDateTime;
import java.util.List;

import encheres.ejb.data.Produit;

public interface IDaoProduit {

	int inserer(Produit produit);

	void modifier(Produit produit);

	void supprimer(int idProduit);

	Produit retrouver(int idProduit);

	List<Produit> listerPourUtilisateur(int idUtilisateur);

	List<Produit> listerAVendre(LocalDateTime dateHeure);

}