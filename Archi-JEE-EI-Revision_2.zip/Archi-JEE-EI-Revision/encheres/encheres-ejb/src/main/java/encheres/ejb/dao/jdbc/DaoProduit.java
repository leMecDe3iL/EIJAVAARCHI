package encheres.ejb.dao.jdbc;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.sql.DataSource;

import encheres.ejb.dao.IDaoProduit;
import encheres.ejb.dao.IDaoUtilisateur;
import encheres.ejb.dao.UtilJdbc;
import encheres.ejb.data.Produit;

@Stateless
@Local
public class DaoProduit implements IDaoProduit {

	// Champs
	@Resource(lookup = "java:/ds/encheres")
	private DataSource dataSource;
	@Inject
	private IDaoUtilisateur daoUtilisateur;

	// Actions

	@Override
	public int inserer(Produit item) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			// Insère le produit
			sql = "INSERT INTO produit ( idutilisateur, nom, prixminimal, debutencheres, finencheres, flagcloture ) VALUES ( ?, ?, ?, ?, ?, ? )";
			stmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setObject(1, item.getUtilisateur() == null ? null : item.getUtilisateur().getId());
			stmt.setObject(2, item.getNom());
			stmt.setObject(3, item.getPrixMinimal());
			stmt.setObject(4, item.getDebutEncheres());
			stmt.setObject(5, item.getFinEncheres());
			stmt.setObject(6, item.isFlagCloture());
			stmt.executeUpdate();

			// Récupère l'identifiant généré par le SGBD
			rs = stmt.getGeneratedKeys();
			rs.next();
			item.setId(rs.getObject(1, Integer.class));

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}

		// Retourne l'identifiant
		return item.getId();
	}

	@Override
	public void modifier(Produit item) {

		Connection cn = null;
		PreparedStatement stmt = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			// Modifie le produit
			sql = "UPDATE produit SET idutilisateur = ?, nom = ?, prixminimal = ?, debutencheres = ?, finencheres = ?, flagcloture = ? WHERE idproduit =  ?";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, item.getUtilisateur() == null ? null : item.getUtilisateur().getId());
			stmt.setObject(2, item.getNom());
			stmt.setObject(3, item.getPrixMinimal());
			stmt.setObject(4, item.getDebutEncheres());
			stmt.setObject(5, item.getFinEncheres());
			stmt.setObject(6, item.isFlagCloture());
			stmt.setObject(7, item.getId());
			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(stmt, cn);
		}
	}

	@Override
	public void supprimer(int idProduit) {

		Connection cn = null;
		PreparedStatement stmt = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			// Supprime le produit
			sql = "DELETE FROM produit WHERE idproduit = ? ";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, idProduit);
			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(stmt, cn);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public Produit retrouver(int idProduit) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			sql = "SELECT * FROM produit WHERE idproduit = ?";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, idProduit);
			rs = stmt.executeQuery();

			if (rs.next()) {
				return construireProduit(rs, true);
			} else {
				return null;
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public List<Produit> listerPourUtilisateur(int idUtilisateur) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			sql = "SELECT * FROM produit WHERE idutilisateur = ? ORDER BY nom";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, idUtilisateur);
			rs = stmt.executeQuery();

			List<Produit> liste = new ArrayList<>();
			while (rs.next()) {
				liste.add(construireProduit(rs, false));
			}
			return liste;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public List<Produit> listerAVendre(LocalDateTime dateHeure) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			sql = "SELECT * FROM produit WHERE finEncheres IS NOT NULL AND finEncheres >= ? ORDER BY finEncheres";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, dateHeure);
			rs = stmt.executeQuery();

			List<Produit> liste = new ArrayList<>();
			while (rs.next()) {
				liste.add(construireProduit(rs, false));
			}
			return liste;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}
	}

	// Méthodes auxiliaires

	protected Produit construireProduit(ResultSet rs, boolean flagComplet) throws SQLException {
		var item = new Produit();
		item.setId(rs.getObject("idproduit", Integer.class));
		item.setNom(rs.getObject("nom", String.class));
		item.setPrixMinimal(rs.getObject("prixminimal", BigDecimal.class));
		item.setDebutEncheres(rs.getObject("debutencheres", LocalDateTime.class));
		item.setFinEncheres(rs.getObject("finencheres", LocalDateTime.class));
		item.setFlagCloture(rs.getObject("flagcloture", Boolean.class));

		if (flagComplet) {
			item.setUtilisateur(daoUtilisateur.retrouver(rs.getObject("idutilisateur", Integer.class)));
		}

		return item;
	}

}
