package encheres.ejb.dao.jdbc;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.sql.DataSource;

import encheres.ejb.dao.IDaoUtilisateur;
import encheres.ejb.dao.UtilJdbc;
import encheres.ejb.data.Utilisateur;

@Stateless
@Local
public class DaoUtilisateur implements IDaoUtilisateur {

	// Champs
	@Resource(lookup = "java:/ds/encheres")
	private DataSource dataSource;

	// Actions

	@Override
	public int inserer(Utilisateur item) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			// Insère le utilisateur
			sql = "INSERT INTO utilisateur ( nom, prenom, email, pseudo, motdepasse, flaggest, credit ) VALUES ( ?, ?, ?, ?, ?, ?, ? )";
			stmt = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setObject(1, item.getNom());
			stmt.setObject(2, item.getPrenom());
			stmt.setObject(3, item.getEmail());
			stmt.setObject(4, item.getPseudo());
			stmt.setObject(5, item.getMotDePasse());
			stmt.setObject(6, item.isFlagGestionnaire());
			stmt.setObject(7, item.getCredit());
			stmt.executeUpdate();

			// Récupère l'identifiant généré par le SGBD
			rs = stmt.getGeneratedKeys();
			rs.next();
			item.setId(rs.getObject(1, Integer.class));

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}

		// Retourne l'identifiant
		return item.getId();
	}

	@Override
	public void modifier(Utilisateur item) {

		Connection cn = null;
		PreparedStatement stmt = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			// Modifie le utilisateur
			sql = "UPDATE utilisateur SET nom = ?, prenom = ?, email = ?, pseudo = ?, motdepasse = ?, flaggest = ?, credit = ? WHERE idutilisateur =  ?";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, item.getNom());
			stmt.setObject(2, item.getPrenom());
			stmt.setObject(3, item.getEmail());
			stmt.setObject(4, item.getPseudo());
			stmt.setObject(5, item.getMotDePasse());
			stmt.setObject(6, item.isFlagGestionnaire());
			stmt.setObject(7, item.getCredit());
			stmt.setObject(8, item.getId());
			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(stmt, cn);
		}
	}

	@Override
	public void supprimer(int idUtilisateur) {

		Connection cn = null;
		PreparedStatement stmt = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			// Supprime le utilisateur
			sql = "DELETE FROM utilisateur WHERE idutilisateur = ? ";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, idUtilisateur);
			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(stmt, cn);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public Utilisateur retrouver(int idUtilisateur) {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			sql = "SELECT * FROM utilisateur WHERE idutilisateur = ?";
			stmt = cn.prepareStatement(sql);
			stmt.setObject(1, idUtilisateur);
			rs = stmt.executeQuery();

			if (rs.next()) {
				return construireUtilisateur(rs, true);
			} else {
				return null;
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.MANDATORY)
	public List<Utilisateur> listerTout() {

		Connection cn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = dataSource.getConnection();

			sql = "SELECT * FROM utilisateur ORDER BY nom, prenom";
			stmt = cn.prepareStatement(sql);
			rs = stmt.executeQuery();

			List<Utilisateur> liste = new ArrayList<>();
			while (rs.next()) {
				liste.add(construireUtilisateur(rs, false));
			}
			return liste;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			UtilJdbc.close(rs, stmt, cn);
		}
	}

	// Méthodes auxiliaires

	protected Utilisateur construireUtilisateur(ResultSet rs, boolean flagComplet) throws SQLException {
		var item = new Utilisateur();
		item.setId(rs.getObject("IdUtilisateur", Integer.class));
		item.setNom(rs.getObject("nom", String.class));
		item.setPrenom(rs.getObject("prenom", String.class));
		item.setEmail(rs.getObject("email", String.class));
		item.setPseudo(rs.getObject("pseudo", String.class));
		item.setMotDePasse(rs.getObject("motdepasse", String.class));
		item.setFlagGestionnaire(rs.getObject("flagGest", Boolean.class));
		item.setCredit(rs.getObject("credit", BigDecimal.class));
		return item;
	}

}
