package encheres.ejb.service.standard;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import encheres.commun.dto.DtoEnchere;
import encheres.commun.exception.ExceptionValidation;
import encheres.commun.service.IServiceEnchere;
import encheres.ejb.dao.IDaoEnchere;
import encheres.ejb.data.mapper.IMapper;

@Stateless
@Remote
public class ServiceEnchere implements IServiceEnchere {

	
	// Champs 
	@Inject
	private IMapper		mapper;
	@Inject
	private IDaoEnchere	daoEnchere;
	

	// Actions 

	@Override
	public int inserer( DtoEnchere dtoEnchere ) throws ExceptionValidation {
		verifierValiditeDonnees( dtoEnchere );
		int id = daoEnchere.inserer( mapper.map( dtoEnchere ) );
		return id;
	}

	@Override
	public void modifier( DtoEnchere dtoEnchere ) throws ExceptionValidation {
		verifierValiditeDonnees( dtoEnchere );
		daoEnchere.modifier( mapper.map( dtoEnchere ) );
	}

	@Override
	public void supprimer( int idEnchere ) throws ExceptionValidation {
		daoEnchere.supprimer(idEnchere);
	}

	@Override
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public DtoEnchere retrouver( int idEnchere ) {
		return mapper.map( daoEnchere.retrouver(idEnchere) );
	}

	
	
	// Méthodes auxiliaires
	
	private void verifierValiditeDonnees( DtoEnchere dtoEnchere ) throws ExceptionValidation {
		
		StringBuilder message = new StringBuilder();
		
		if ( dtoEnchere.getProduit() == null ) {
			message.append( "\nLe produit est obligatoire." );
		}
		
		if ( dtoEnchere.getUtilisateur() == null ) {
			message.append( "\nL'utilisateur est obligatoire." );
		}
		
		if ( dtoEnchere.getMontant() == null  ) {
			message.append( "\nLe montant est obligatoire." );
		} else 	if ( dtoEnchere.getMontant().doubleValue() < 0 ) {
			message.append( "\nLe montant doit être supérieur ou égal à zéro." );
		}
		
		if ( message.length() > 0 ) {
			throw new ExceptionValidation( message.toString().substring(1) );
		}
	}

}
