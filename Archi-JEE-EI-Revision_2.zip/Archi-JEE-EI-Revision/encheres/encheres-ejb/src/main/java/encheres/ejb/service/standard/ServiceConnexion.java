package encheres.ejb.service.standard;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import encheres.commun.dto.DtoUtilisateur;
import encheres.commun.service.IServiceConnexion;
import encheres.ejb.dao.IDaoConnexion;
import encheres.ejb.data.mapper.IMapper;

@Stateless
@Remote
public class ServiceConnexion implements IServiceConnexion {

	
	// Champs 
	@Inject
	private IMapper			mapper;
	@Inject
	private IDaoConnexion	daoConnexion;

	
	// Actions

	@Override @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public DtoUtilisateur sessionUtilisateurOuvrir(String compte, String motDePasse) {
		return mapper.map( daoConnexion.validerAuthentification(compte, motDePasse) );
	}

	@Override @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void sessionUtilisateurFermer() {
		// Cette méthode ne fait rien
	}

}
