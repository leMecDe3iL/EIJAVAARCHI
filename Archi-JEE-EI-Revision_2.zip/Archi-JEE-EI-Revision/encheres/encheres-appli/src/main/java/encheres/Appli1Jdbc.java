package encheres;

import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Lazy;

import encheres.commun.service.IServiceUtilisateur;
import encheres.emb.dao.IDaoUtilisateur;
import encheres.gui.model.IModelConnexion;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import jfox.javafx.util.UtilFX;
import jfox.javafx.view.ManagerGuiAbstract;
import jfox.jdbc.DataSourceSingleConnection;


@Lazy(false)
@ComponentScan(basePackages = {
		"encheres.gui.data.mapper",
		"encheres.gui.view",
		"encheres.gui.model.standard",
		"encheres.emb.data.mapper",
		"encheres.emb.service.util",
		"encheres.emb.service.standard",
		"encheres.emb.dao.jdbc1",
		"encheres.emb.dao.jdbc2",
	}, lazyInit = true)
public class Appli1Jdbc extends Application {
	
	
	// Logger
	
	private static final Logger logger = getLogger();

	
	// Titre de la fenêtre
	private static final String TITRE = "Enchères JDBC";

	
	// Champs
	
	private AnnotationConfigApplicationContext	context;
	
	
	// Actions
	
	@Override
	public final void start(Stage stage) {
		
		try {
			
			// Context
			context = new AnnotationConfigApplicationContext();
			context.register( Appli1Jdbc.class );
			context.refresh();

			// ManagerGui
	    	var managerGui = context.getBean( ManagerGuiAbstract.class );
	    	managerGui.setFactoryController( context::getBean );
			managerGui.setStage( stage );
			managerGui.configureStage();

	    	
	    	// Trace
	    	
	    	StringBuilder sbMessage = new StringBuilder();
	    	try {
				var dao = context.getBean( IDaoUtilisateur.class );
				sbMessage.append( "\n    Couche DAO     : " ).append( dao.getClass().getPackageName() );
			} catch (NoSuchBeanDefinitionException e) {
			}
	    	try {
		    	var service = context.getBean( IServiceUtilisateur.class );
	    		sbMessage.append( "\n    Couche Service : " ).append( service.getClass().getPackageName() );
			} catch (NoSuchBeanDefinitionException e) {
			}
	    	try {
		    	var model = context.getBean( IModelConnexion.class );
	    		sbMessage.append( "\n    Couche Model   : " ).append( model.getClass().getPackageName() );
			} catch (NoSuchBeanDefinitionException e) {
			}
			logger.log(Level.CONFIG, sbMessage.toString() );

			
			// Affiche le stage
			var modelConnexion = context.getBean( IModelConnexion.class );
			stage.titleProperty().bind(Bindings.createStringBinding( () -> {
				var utilisateurActif = modelConnexion.getUtilisateurActif();
				if ( utilisateurActif != null ) {
					return TITRE + " - " + utilisateurActif.getNom() + " " +utilisateurActif.getPrenom();
				} else {
					return TITRE;
				}
			},modelConnexion.utilisateurActifProperty())  );
			stage.show();
			
		} catch(Exception e) {
			UtilFX.unwrapException(e).printStackTrace();
			logger.log( Level.SEVERE, "Echec du démarrage", e );
	        Alert alert = new Alert(AlertType.ERROR);
	        alert.setHeaderText( "Impossible de démarrer l'application." );
	        alert.showAndWait();
	        Platform.exit();
		}

	}
	
	@Override
	public final void stop() throws Exception {
		
		// Message de fermeture
		logger.config( "\n    Fermeture de l'application" );

		if (context != null ) {
			context.close();
		}
	}
	

	
	// Méthodes auxiliaires
	
	private static Logger getLogger() {

		try {
			InputStream in = 
				Thread.currentThread().getContextClassLoader().getResourceAsStream("META-INF/logging.properties");
			LogManager.getLogManager().readConfiguration( in );
			in.close();
		} catch ( Exception e ) {
			e.printStackTrace();
		}		

		return Logger.getLogger( Appli1Jdbc.class.getName() );
	}

	
	// Classe interne Main
	
	public static class Main {
		public static void main(String[] args) {
			Application.launch( Appli1Jdbc.class, args);
		}
	}

	
	// Définition des beans pour Spring

	@Bean
	public DataSource dataSource() {
		return new DataSourceSingleConnection(
				UtilFX.getInputStram( "classpath:/META-INF/jdbc.properties" )
			 );
	}	
}
