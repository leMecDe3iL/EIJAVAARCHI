SET search_path TO encheres;


-- Supprime toutes les données
DELETE FROM enchere;
DELETE FROM produit;
DELETE FROM utilisateur;


-- Insère les données

INSERT INTO utilisateur ( idutilisateur, nom, prenom, email, pseudo, motdepasse, flaggest, credit ) VALUES 
( 1, 'ADMIN', 'admin', 'admin@3il.fr', 'admin', 'admin', TRUE, 25.0 ),
( 2, 'VENDEUR', 'v', 'vendeur@3il.fr', 'v', 'v', FALSE, 0.0 ),
( 3, 'ACHETEUR1', 'a1', 'a2@3il.fr', 'a1', 'a1', FALSE, 300.0 ),
( 4, 'ACHETEUR2', 'a2', 'a2@3il.fr', 'a2', 'a2', FALSE, 400.0 );

ALTER TABLE utilisateur ALTER COLUMN idutilisateur RESTART WITH 5;


INSERT INTO produit ( idproduit, idutilisateur, nom, prixminimal, debutEncheres, finEncheres, flagcloture ) VALUES 
( 1, 1, 'Frigo', 150.0,  {ts '2024-01-01 00:00:00'}, {ts '2024-01-28 23:59:59'}, FALSE ),
( 2, 1, 'Télévision', 200.0, {ts '2024-01-01 00:00:00'}, {ts '2024-01-27 23:59:59'}, FALSE  ),
( 3, 2, 'Vélo', 400.0, NULL, NULL, FALSE  ),
( 4, 2, 'Livre', 10.0, NULL, NULL, FALSE  ),
( 5, 3, 'Souris', 8.0, {ts '2024-01-06 00:00:00'}, {ts '2024-01-26 23:59:59'}, FALSE  ),
( 6, 3, 'Clavier', 15.0, {ts '2024-01-05 00:00:00'}, {ts '2024-01-25 23:59:59'}, FALSE  );

ALTER TABLE produit ALTER COLUMN idproduit RESTART WITH 7;
  


INSERT INTO enchere ( idenchere, idproduit, idutilisateur, montant, dateheure ) VALUES 
( 1, 3, 3, 410,  {ts '2024-01-01 10:00:00'} ),
( 2, 3, 4, 420,  {ts '2024-01-01 10:05:00'} ),
( 3, 3, 3, 450,  {ts '2024-01-01 10:07:00'} ),
( 4, 3, 4, 460,  {ts '2024-01-01 10:20:00'} ),
( 5, 3, 3, 480,  {ts '2024-01-01 10:22:00'} ),
( 6, 3, 4, 490,  {ts '2024-01-01 10:33:00'} );

ALTER TABLE enchere ALTER COLUMN idenchere RESTART WITH 7;
 
