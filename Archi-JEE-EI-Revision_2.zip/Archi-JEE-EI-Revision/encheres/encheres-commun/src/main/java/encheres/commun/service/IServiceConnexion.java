package encheres.commun.service;

import encheres.commun.dto.DtoUtilisateur;

public interface IServiceConnexion {

	DtoUtilisateur sessionUtilisateurOuvrir(String pseudo, String motDePasse);

	void sessionUtilisateurFermer();

}