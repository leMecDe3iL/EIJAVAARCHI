package encheres.commun.service;

import encheres.commun.dto.DtoEnchere;
import encheres.commun.exception.ExceptionValidation;

public interface IServiceEnchere {

	int inserer(DtoEnchere dtoEnchere) throws ExceptionValidation;

	void modifier(DtoEnchere dtoEnchere) throws ExceptionValidation;

	void supprimer(int idEnchere) throws ExceptionValidation;

	DtoEnchere retrouver(int idEnchere);

}