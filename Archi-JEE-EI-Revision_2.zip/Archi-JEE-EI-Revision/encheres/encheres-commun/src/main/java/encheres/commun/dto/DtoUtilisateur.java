package encheres.commun.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;


@SuppressWarnings("serial")
public class DtoUtilisateur implements Serializable{
	
	
	// Champs
	
	private int			id;
	private String		nom;
	private String		prenom;
	private String		email;
	private String		pseudo;
	private String		motDePasse;
	private boolean 	flagGestionnaire;
	private BigDecimal	credit;
	
	
	// Getters & Setters
	
	public int getId() {
		return id;
	}

	public void setId(int idUtilisateur) {
		this.id = idUtilisateur;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getPseudo() {
		return pseudo;
	}

	public void setPseudo(String pseudo) {
		this.pseudo = pseudo;
	}

	public String getMotDePasse() {
		return motDePasse;
	}

	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}

	public BigDecimal getCredit() {
		return credit;
	}

	public void setCredit(BigDecimal credit) {
		this.credit = credit;
	}

	public boolean isFlagGestionnaire() {
		return flagGestionnaire;
	}

	public void setFlagGestionnaire(boolean flagGestionnaire) {
		this.flagGestionnaire = flagGestionnaire;
	}

	
	//hashCode() & equals()
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof DtoUtilisateur))
			return false;
		DtoUtilisateur other = (DtoUtilisateur) obj;
		return id == other.id;
	}
}
