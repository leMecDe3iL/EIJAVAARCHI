package encheres.commun.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;


@SuppressWarnings("serial")
public class DtoEnchere implements Serializable{

	
	// Champs
	
	private int				id;
	private DtoProduit		produit;
	private DtoUtilisateur	utilisateur;
	private BigDecimal		montant;
	private LocalDateTime	dateHeure;
	
	
	// Getters & Setters

	public int getId() {
		return id;
	}

	public void setId(int idEnchere) {
		this.id = idEnchere;
	}

	public DtoProduit getProduit() {
		return produit;
	}

	public void setProduit(DtoProduit produit) {
		this.produit = produit;
	}

	public DtoUtilisateur getUtilisateur() {
		return utilisateur;
	}

	public void setUtilisateur(DtoUtilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}

	public BigDecimal getMontant() {
		return montant;
	}

	public void setMontant(BigDecimal montant) {
		this.montant = montant;
	}

	public LocalDateTime getDateHeure() {
		return dateHeure;
	}

	public void setDateHeure(LocalDateTime dateHeure) {
		this.dateHeure = dateHeure;
	}

	
	//hashCode() & equals()
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof DtoEnchere))
			return false;
		DtoEnchere other = (DtoEnchere) obj;
		return id == other.id;
	}
	
	
}
