package encheres.commun.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;


@SuppressWarnings("serial")
public class DtoProduit implements Serializable{

	// Champs

	private int id;
	private DtoUtilisateur utilisateur;
	private String nom;
	private BigDecimal prixMinimal;
	private LocalDateTime debutEncheres;
	private LocalDateTime finEncheres;
	private boolean flagCloture;
	private int nbEncheres;
	private BigDecimal meilleureOffre;

	// Getters & Setters

	public int getId() {
		return id;
	}

	public void setId(int idProduit) {
		this.id = idProduit;
	}

	public DtoUtilisateur getUtilisateur() {
		return utilisateur;
	}

	public void setUtilisateur(DtoUtilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public BigDecimal getPrixMinimal() {
		return prixMinimal;
	}

	public void setPrixMinimal(BigDecimal prixMinimal) {
		this.prixMinimal = prixMinimal;
	}

	public LocalDateTime getDebutEncheres() {
		return debutEncheres;
	}

	public void setDebutEncheres(LocalDateTime ebutEnchere) {
		this.debutEncheres = ebutEnchere;
	}

	public LocalDateTime getFinEncheres() {
		return finEncheres;
	}

	public void setFinEncheres(LocalDateTime finEnchere) {
		this.finEncheres = finEnchere;
	}

	public boolean isFlagCloture() {
		return flagCloture;
	}

	public void setFlagCloture(boolean flagCloture) {
		this.flagCloture = flagCloture;
	}

	public int getNbEncheres() {
		return nbEncheres;
	}

	public void setNbEncheres(int nbEncheres) {
		this.nbEncheres = nbEncheres;
	}

	public BigDecimal getMeilleureOffre() {
		return meilleureOffre;
	}

	public void setMeilleureOffre(BigDecimal meilleureOffre) {
		this.meilleureOffre = meilleureOffre;
	}

	// hashCode() & equals()

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof DtoProduit))
			return false;
		DtoProduit other = (DtoProduit) obj;
		return id == other.id;
	}

}
