package encheres.commun.service;

import java.time.LocalDateTime;
import java.util.List;

import encheres.commun.dto.DtoProduit;
import encheres.commun.exception.ExceptionValidation;

public interface IServiceProduit {

	int inserer(DtoProduit dtoProduit) throws ExceptionValidation;

	void modifier(DtoProduit dtoProduit) throws ExceptionValidation;

	void supprimer(int idProduit) throws ExceptionValidation;

	DtoProduit retrouver(int idProduit);

	List<DtoProduit> listerAVendre( LocalDateTime dateHeure );

	List<DtoProduit> listerAVendre(int idUtilisateur);

}