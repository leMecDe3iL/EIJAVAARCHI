package jfox.javafx.view;


public interface IEnumView {

	View getView();

}