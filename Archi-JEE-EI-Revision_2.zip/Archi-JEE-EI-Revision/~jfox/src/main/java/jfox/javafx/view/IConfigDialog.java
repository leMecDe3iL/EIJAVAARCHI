package jfox.javafx.view;

import javafx.stage.Stage;


public interface IConfigDialog extends IFactoryScene {
	
	void configureStage( Stage stage );

}