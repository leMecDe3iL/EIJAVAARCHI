package jfox.javafx.view;

import javafx.scene.Scene;


public interface IFactoryScene {

	Scene createScene( View view );

}
