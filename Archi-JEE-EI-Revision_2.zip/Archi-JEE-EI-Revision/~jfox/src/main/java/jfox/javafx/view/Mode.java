package jfox.javafx.view;

public enum Mode {
	
	DISPLAy,
	NEW,
	EDIT,
	;

}
