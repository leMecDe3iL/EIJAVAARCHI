package jfox.jasperreports;


public interface IEnumReport {

	String getPath();

}